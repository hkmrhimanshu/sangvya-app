# Sangvya (v2.0) – Decentralized P2P Mesh & Spatial Friend Radar

[![Build Sangvya APK](https://github.com/OWNER/REPO/actions/workflows/build-sangvya.yml/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/build-sangvya.yml)
![Platform](https://img.shields.io/badge/Platform-Android%208.0%2B%20%28API%2026%2B%29-brightgreen)
![Kotlin](https://img.shields.io/badge/Kotlin-1.9.22-blue)
![Jetpack Compose](https://img.shields.io/badge/UI-Jetpack%20Compose%20%26%20Material%203-purple)
![Design](https://img.shields.io/badge/Design-Nothing%20OS%20Glassmorphism-black)

**Sangvya** is a fully functional, offline-first Android application featuring real peer-to-peer (P2P) mesh networking, real-time spatial GPS radar locating, dynamic QR code connection pairing, and end-to-end encrypted direct & group messaging. Designed with a **premium Glassmorphic aesthetic**, it features a true OLED deep black background, glassmorphism cards, and the signature **Sangvya Red** (`#F9031D`) neon accents.

---

## 1. Official Brand Identity & Logo

- **App Name:** `Sangvya`
- **Package Name:** `com.sangvya.app`
- **Version Name:** `2.0`
- **Version Code:** `2`
- **Design Philosophy:** Sangvya Original Glassmorphic Design (Deep Black `#000000`, Sangvya Red `#F9031D`, Glass Surfaces)

### Official Logo Integration
The official Sangvya logo—featuring the central group silhouette enclosed in a white hexagonal network with 6 vibrant red node vertices—is deeply integrated throughout the app:
1. **Android Launcher Icons:** Standard square icons in all Android densities (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`).
2. **Adaptive Launcher Icons:** Android 8.0+ adaptive icon format with safe-zone foreground (`ic_launcher_foreground.png`) and true black background (`mipmap-anydpi-v26/ic_launcher.xml`).
3. **Animated Splash Screen:** High-resolution vector/bitmap logo with pulse glow animation and versioning.
4. **App Header Branding:** Top AppBar displays the official logo alongside the `SANGVYA` wordmark.
5. **About & Identity Screen:** High-resolution branding display with package metadata and architecture credits.
6. **Notification Icon:** Alpha-channel status bar silhouette (`ic_notification_sangvya.png`).

---

## 2. Key Architecture & Features

### Offline-First P2P Mesh Connection (2–8 Peers)
- **Google Nearby Connections API:** Powered by the `P2P_CLUSTER` mesh strategy, enabling devices to discover and connect simultaneously without requiring cellular data, internet, or centralized servers.
- **Auto-Discovery & Advertising:** Seamless Bluetooth Low Energy (BLE) and local Wi-Fi LAN discovery.
- **Safety Controls:** Instant Accept, Reject, Disconnect, and Block functionality.

### Dynamic QR Code Connection System
- **Personal QR Code:** Generates a cryptographically validated QR code with user identity parameters.
- **Group Invite QR Code:** Allows instant joining of a local mesh cluster session.
- **Live CameraX Scanner:** Integrated ZXing multi-format analyzer that scans and verifies Sangvya protocol codes in real time, displaying peer details before establishing a connection.

### Live GPS Spatial Radar & Telemetry
- **Fused Location Provider:** Accurate GPS telemetry with user-controlled consent toggles.
- **Haversine Distance Engine:** Computes real distances in meters and kilometers between linked peers.
- **Relative Azimuth Bearing:** Computes true directional heading (0°–360°) so friends can find each other in crowds, events, or outdoor areas.
- **Spatial Radar Canvas:** Animated sweeping concentric radar screen visually plotting friends according to their real spatial coordinates.

### Proximity Distance Alerts
- Configurable alert threshold slider (10m to 1000m).
- Haptic vibration feedback via `VibratorManager`.
- Audible alert tones when friends cross proximity boundaries.
- Smart deduplication to prevent repeated notifications.

### Decentralized Direct & Group Messaging
- **1-on-1 Direct Chat:** Encrypted byte payload delivery over P2P radio channels.
- **Mesh Group Chat:** Broadcasts messages across all connected peers (up to 8 participants).
- **Local Persistence:** Room Database (`AppDatabase`) ensures message history and friend registries are stored safely on-device.

---

## 3. Technology Stack

- **Language:** Kotlin 1.9.22
- **UI Framework:** Jetpack Compose with Material 3
- **Local Storage:** Room Database (2.6.1) with KSP
- **Preferences:** Jetpack DataStore Preferences
- **P2P Networking:** Google Play Services Nearby Connections (19.3.0)
- **Location & GPS:** Google Play Services Location (21.3.0)
- **Camera & QR:** AndroidX CameraX (1.3.2) & ZXing Core (3.5.3)
- **Build System:** Gradle 8.5 with Android Gradle Plugin 8.3.0

---

## 4. How to Upload to GitHub & Build APK with GitHub Actions

This project includes a complete, pre-configured GitHub Actions CI/CD workflow (`.github/workflows/build-sangvya.yml`) that automatically compiles the debug APK in the cloud.

### Step 1: Initialize Git and Push to GitHub

1. Unzip the project folder or open a terminal in the root `Sangvya` folder:
   ```bash
   cd Sangvya
   git init
   git add .
   git commit -m "Initial commit of Sangvya v2.0 Android Studio project"
   ```

2. Create a new repository on [GitHub](https://github.com/new) named `sangvya` (or any preferred name).

3. Link and push your code:
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/sangvya.git
   git push -u origin main
   ```

### Step 2: Automatic APK Compilation
1. As soon as you push to `main` (or trigger the **Workflow Dispatch** button in GitHub), GitHub Actions will automatically start building the application.
2. The workflow installs JDK 17, sets up Gradle 8.5, and runs:
   ```bash
   ./gradlew assembleDebug --stacktrace
   ```
3. Once the build completes (usually 1–2 minutes), go to the **Actions** tab on your GitHub repository.
4. Click on the latest workflow run: **"Build Sangvya Android APK"**.
5. Scroll down to the **Artifacts** section at the bottom of the page.
6. Click **`sangvya-debug-apk`** to download your compiled `app-debug.apk` directly to your computer or phone!

---

## 5. Building Locally in Android Studio

If you prefer building locally:
1. Open **Android Studio** (Iguana, Jellyfish, or newer recommended).
2. Select **File > Open...** and choose the `Sangvya` directory.
3. Allow Android Studio to sync the Gradle project.
4. Select an Android device or emulator running Android 8.0+ (API 26+).
5. Click **Run > Run 'app'** (or press `Shift + F10`).
6. Alternatively, in the Android Studio terminal, run:
   ```bash
   ./gradlew assembleDebug
   ```
   The compiled APK will be located at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## 6. Project File Hierarchy

```
Sangvya/
├── .github/
│   └── workflows/
│       └── build-sangvya.yml        # GitHub Actions CI/CD workflow
├── app/
│   ├── build.gradle.kts             # App-level build configuration
│   ├── proguard-rules.pro           # Proguard obfuscation rules
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml  # Complete permissions & Activity
│           ├── assets/
│           │   └── sangvya_icon_512.png
│           ├── java/com/sangvya/app/
│           │   ├── SangvyaApp.kt    # Application singleton container
│           │   ├── MainActivity.kt  # Compose host & runtime permissions
│           │   ├── data/
│           │   │   ├── model/       # Friend, ChatMessage, QrPayload, Alerts
│           │   │   ├── local/       # Room DB, Entity & DAO definitions
│           │   │   ├── preference/  # DataStore user preferences
│           │   │   ├── nearby/      # Google Nearby Connections P2P manager
│           │   │   ├── location/    # FusedLocation GPS & bearing calculations
│           │   │   ├── qr/          # ZXing QR Generator & CameraX Analyzer
│           │   │   └── repository/  # Central SangvyaRepository
│           │   └── ui/
│           │       ├── theme/       # Sangvya colors, type, and theme
│           │       ├── components/  # GlassCard, RadarCanvas, StatusPill, TopBar
│           │       ├── screens/     # Splash, Home, Nearby, QR, Radar, Chat, Settings
│           │       └── navigation/  # SangvyaNavHost navigation routes
│           └── res/
│               ├── drawable/        # Logo assets & notification icon
│               ├── drawable-nodpi/  # High-res splash logo
│               ├── mipmap-*/        # Launcher icons & adaptive foregrounds
│               └── values/          # Strings, colors, and base themes
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
├── build.gradle.kts                 # Root project plugins
├── gradle.properties                # Build JVM flags & AndroidX flags
├── gradlew                          # Linux/macOS Gradle launcher
├── gradlew.bat                      # Windows Gradle launcher
├── settings.gradle.kts              # Module configuration
└── README.md                        # Documentation & setup guide
```

---

## 7. License & Credits

Developed for **Sangvya**. All branding, official logos, and assets are strictly reserved for the Sangvya project.
Distributed under the MIT License for open collaborative development.
