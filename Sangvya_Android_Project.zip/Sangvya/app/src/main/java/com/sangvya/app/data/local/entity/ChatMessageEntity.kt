package com.sangvya.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sangvya.app.data.model.ChatMessage
import com.sangvya.app.data.model.MessageStatus

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val peerId: String,
    val senderName: String,
    val content: String,
    val timestamp: Long,
    val isIncoming: Boolean,
    val isGroup: Boolean,
    val status: String
) {
    fun toModel(): ChatMessage {
        val msgStatus = try {
            MessageStatus.valueOf(status)
        } catch (e: Exception) {
            MessageStatus.SENT
        }
        return ChatMessage(
            id = id,
            peerId = peerId,
            senderName = senderName,
            content = content,
            timestamp = timestamp,
            isIncoming = isIncoming,
            isGroup = isGroup,
            status = msgStatus
        )
    }

    companion object {
        fun fromModel(msg: ChatMessage): ChatMessageEntity {
            return ChatMessageEntity(
                id = msg.id,
                peerId = msg.peerId,
                senderName = msg.senderName,
                content = msg.content,
                timestamp = msg.timestamp,
                isIncoming = msg.isIncoming,
                isGroup = msg.isGroup,
                status = msg.status.name
            )
        }
    }
}
