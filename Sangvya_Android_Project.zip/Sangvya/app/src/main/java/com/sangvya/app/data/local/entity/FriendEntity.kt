package com.sangvya.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sangvya.app.data.model.ConnectionStatus
import com.sangvya.app.data.model.Friend

@Entity(tableName = "friends")
data class FriendEntity(
    @PrimaryKey val id: String,
    val endpointId: String = "",
    val displayName: String,
    val status: String = ConnectionStatus.DISCONNECTED.name,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val distanceMeters: Float? = null,
    val bearingDegrees: Float? = null,
    val isLocationShared: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
) {
    fun toModel(): Friend {
        val connStatus = try {
            ConnectionStatus.valueOf(status)
        } catch (e: Exception) {
            ConnectionStatus.DISCONNECTED
        }
        return Friend(
            id = id,
            endpointId = endpointId,
            displayName = displayName,
            status = connStatus,
            latitude = latitude,
            longitude = longitude,
            distanceMeters = distanceMeters,
            bearingDegrees = bearingDegrees,
            isLocationShared = isLocationShared,
            lastSeenTimestamp = lastSeenTimestamp
        )
    }

    companion object {
        fun fromModel(friend: Friend): FriendEntity {
            return FriendEntity(
                id = friend.id,
                endpointId = friend.endpointId,
                displayName = friend.displayName,
                status = friend.status.name,
                latitude = friend.latitude,
                longitude = friend.longitude,
                distanceMeters = friend.distanceMeters,
                bearingDegrees = friend.bearingDegrees,
                isLocationShared = friend.isLocationShared,
                lastSeenTimestamp = friend.lastSeenTimestamp
            )
        }
    }
}
