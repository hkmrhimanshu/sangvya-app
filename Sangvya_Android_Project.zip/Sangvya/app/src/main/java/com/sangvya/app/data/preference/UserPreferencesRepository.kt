package com.sangvya.app.data.preference

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sangvya.app.data.model.DistanceAlertSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sangvya_preferences")

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val USER_ID = stringPreferencesKey("user_id")
        val DISPLAY_NAME = stringPreferencesKey("display_name")
        val LOCATION_SHARING = booleanPreferencesKey("location_sharing")
        val ALERTS_ENABLED = booleanPreferencesKey("alerts_enabled")
        val ALERT_THRESHOLD = floatPreferencesKey("alert_threshold")
        val ALERT_SOUND = booleanPreferencesKey("alert_sound")
        val ALERT_VIBRATION = booleanPreferencesKey("alert_vibration")
        val BLOCKED_USERS = stringSetPreferencesKey("blocked_users")
    }

    val userIdFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[PreferencesKeys.USER_ID] ?: UUID.randomUUID().toString()
    }

    val displayNameFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[PreferencesKeys.DISPLAY_NAME] ?: "Sangvya Peer"
    }

    val locationSharingFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[PreferencesKeys.LOCATION_SHARING] ?: true
    }

    val alertSettingsFlow: Flow<DistanceAlertSettings> = context.dataStore.data.map { prefs ->
        DistanceAlertSettings(
            alertsEnabled = prefs[PreferencesKeys.ALERTS_ENABLED] ?: true,
            thresholdMeters = prefs[PreferencesKeys.ALERT_THRESHOLD] ?: 100f,
            soundEnabled = prefs[PreferencesKeys.ALERT_SOUND] ?: true,
            vibrationEnabled = prefs[PreferencesKeys.ALERT_VIBRATION] ?: true
        )
    }

    val blockedUsersFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[PreferencesKeys.BLOCKED_USERS] ?: emptySet()
    }

    suspend fun setUserId(id: String) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.USER_ID] = id
        }
    }

    suspend fun setDisplayName(name: String) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.DISPLAY_NAME] = name.trim()
        }
    }

    suspend fun setLocationSharing(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.LOCATION_SHARING] = enabled
        }
    }

    suspend fun updateAlertSettings(settings: DistanceAlertSettings) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.ALERTS_ENABLED] = settings.alertsEnabled
            prefs[PreferencesKeys.ALERT_THRESHOLD] = settings.thresholdMeters
            prefs[PreferencesKeys.ALERT_SOUND] = settings.soundEnabled
            prefs[PreferencesKeys.ALERT_VIBRATION] = settings.vibrationEnabled
        }
    }

    suspend fun blockUser(userId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[PreferencesKeys.BLOCKED_USERS]?.toMutableSet() ?: mutableSetOf()
            current.add(userId)
            prefs[PreferencesKeys.BLOCKED_USERS] = current
        }
    }

    suspend fun unblockUser(userId: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[PreferencesKeys.BLOCKED_USERS]?.toMutableSet() ?: mutableSetOf()
            current.remove(userId)
            prefs[PreferencesKeys.BLOCKED_USERS] = current
        }
    }
}
