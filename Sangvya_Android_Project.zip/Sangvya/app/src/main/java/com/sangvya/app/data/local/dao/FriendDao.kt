package com.sangvya.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.sangvya.app.data.local.entity.FriendEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FriendDao {
    @Query("SELECT * FROM friends ORDER BY lastSeenTimestamp DESC")
    fun getAllFriendsFlow(): Flow<List<FriendEntity>>

    @Query("SELECT * FROM friends WHERE status = 'CONNECTED'")
    fun getConnectedFriendsFlow(): Flow<List<FriendEntity>>

    @Query("SELECT * FROM friends WHERE id = :id LIMIT 1")
    suspend fun getFriendById(id: String): FriendEntity?

    @Query("SELECT * FROM friends WHERE endpointId = :endpointId LIMIT 1")
    suspend fun getFriendByEndpointId(endpointId: String): FriendEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(friend: FriendEntity)

    @Update
    suspend fun update(friend: FriendEntity)

    @Query("DELETE FROM friends WHERE id = :id")
    suspend fun deleteFriend(id: String)

    @Query("UPDATE friends SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("UPDATE friends SET distanceMeters = :distance, bearingDegrees = :bearing, latitude = :lat, longitude = :lng, lastSeenTimestamp = :timestamp WHERE id = :id")
    suspend fun updateLocation(id: String, distance: Float?, bearing: Float?, lat: Double?, lng: Double?, timestamp: Long)

    @Query("UPDATE friends SET status = 'DISCONNECTED' WHERE status = 'CONNECTED'")
    suspend fun markAllDisconnected()
}
