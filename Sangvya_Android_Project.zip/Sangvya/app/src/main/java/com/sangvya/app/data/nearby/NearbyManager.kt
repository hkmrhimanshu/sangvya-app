package com.sangvya.app.data.nearby

import android.content.Context
import android.util.Log
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

data class DiscoveredPeer(
    val endpointId: String,
    val endpointName: String = "Peer",
    val serviceId: String = ""
)

data class ConnectionRequest(
    val endpointId: String,
    val endpointName: String = "Peer",
    val authenticationDigits: String = ""
)

sealed class NearbyEvent {
    data class MessageReceived(val endpointId: String, val senderName: String, val text: String, val isGroup: Boolean, val timestamp: Long) : NearbyEvent()
    data class LocationReceived(val endpointId: String, val latitude: Double, val longitude: Double, val timestamp: Long) : NearbyEvent()
    data class PeerConnected(val endpointId: String, val endpointName: String) : NearbyEvent()
    data class PeerDisconnected(val endpointId: String) : NearbyEvent()
}

class NearbyManager(private val context: Context) {

    private val serviceId = "com.sangvya.app.mesh"
    private val strategy = Strategy.P2P_CLUSTER
    private val client = Nearby.getConnectionsClient(context)
    private val scope = CoroutineScope(Dispatchers.IO)

    private val _isAdvertising = MutableStateFlow(false)
    val isAdvertising: StateFlow<Boolean> = _isAdvertising.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<Map<String, DiscoveredPeer>>(emptyMap())
    val discoveredPeers: StateFlow<Map<String, DiscoveredPeer>> = _discoveredPeers.asStateFlow()

    private val _connectedEndpoints = MutableStateFlow<Map<String, String>>(emptyMap())
    val connectedEndpoints: StateFlow<Map<String, String>> = _connectedEndpoints.asStateFlow()

    private val _incomingRequests = MutableStateFlow<List<ConnectionRequest>>(emptyList())
    val incomingRequests: StateFlow<List<ConnectionRequest>> = _incomingRequests.asStateFlow()

    private val _events = MutableSharedFlow<NearbyEvent>()
    val events: SharedFlow<NearbyEvent> = _events.asSharedFlow()

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                val bytes = payload.asBytes() ?: return
                val raw = String(bytes, Charsets.UTF_8)
                parseIncomingPayload(endpointId, raw)
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private val connectionLifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, connectionInfo: ConnectionInfo) {
            try {
                val req = ConnectionRequest(
                    endpointId = endpointId,
                    endpointName = connectionInfo.endpointName ?: "Sangvya Peer",
                    authenticationDigits = connectionInfo.authenticationDigits ?: ""
                )
                _incomingRequests.value = _incomingRequests.value + req
            } catch (e: Throwable) {
                Log.e("SangvyaNearby", "Error in onConnectionInitiated", e)
            }
        }

        override fun onConnectionResult(endpointId: String, resolution: ConnectionResolution) {
            _incomingRequests.value = _incomingRequests.value.filter { it.endpointId != endpointId }
            when (resolution.status.statusCode) {
                ConnectionsStatusCodes.STATUS_OK -> {
                    val peerName = _discoveredPeers.value[endpointId]?.endpointName ?: "Peer"
                    _connectedEndpoints.value = _connectedEndpoints.value + (endpointId to peerName)
                    scope.launch {
                        _events.emit(NearbyEvent.PeerConnected(endpointId, peerName))
                    }
                }
                else -> {
                    Log.d("SangvyaNearby", "Connection failed: ${resolution.status.statusCode}")
                }
            }
        }

        override fun onDisconnected(endpointId: String) {
            _connectedEndpoints.value = _connectedEndpoints.value - endpointId
            scope.launch {
                _events.emit(NearbyEvent.PeerDisconnected(endpointId))
            }
        }
    }

    private val endpointDiscoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val peer = DiscoveredPeer(endpointId, info.endpointName, info.serviceId)
            _discoveredPeers.value = _discoveredPeers.value + (endpointId to peer)
        }

        override fun onEndpointLost(endpointId: String) {
            _discoveredPeers.value = _discoveredPeers.value - endpointId
        }
    }

    fun startAdvertising(localDisplayName: String) {
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising(localDisplayName, serviceId, connectionLifecycleCallback, options)
            .addOnSuccessListener { _isAdvertising.value = true }
            .addOnFailureListener { _isAdvertising.value = false }
    }

    fun stopAdvertising() {
        client.stopAdvertising()
        _isAdvertising.value = false
    }

    fun startDiscovery() {
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(serviceId, endpointDiscoveryCallback, options)
            .addOnSuccessListener { _isDiscovering.value = true }
            .addOnFailureListener { _isDiscovering.value = false }
    }

    fun stopDiscovery() {
        client.stopDiscovery()
        _isDiscovering.value = false
        _discoveredPeers.value = emptyMap()
    }

    fun requestConnection(localDisplayName: String, endpointId: String) {
        try {
            val name = if (localDisplayName.isBlank()) "Sangvya Peer" else localDisplayName
            client.requestConnection(name, endpointId, connectionLifecycleCallback)
                .addOnSuccessListener {
                    Log.d("SangvyaNearby", "Connection requested to ")
                }
                .addOnFailureListener { e ->
                    Log.e("SangvyaNearby", "Failed to request connection to ", e)
                }
        } catch (e: Throwable) {
            Log.e("SangvyaNearby", "Exception in requestConnection", e)
        }
    }

    fun acceptConnection(endpointId: String) {
        client.acceptConnection(endpointId, payloadCallback)
        _incomingRequests.value = _incomingRequests.value.filter { it.endpointId != endpointId }
    }

    fun rejectConnection(endpointId: String) {
        client.rejectConnection(endpointId)
        _incomingRequests.value = _incomingRequests.value.filter { it.endpointId != endpointId }
    }

    fun disconnect(endpointId: String) {
        client.disconnectFromEndpoint(endpointId)
        _connectedEndpoints.value = _connectedEndpoints.value - endpointId
    }

    fun stopAll() {
        stopAdvertising()
        stopDiscovery()
        client.stopAllEndpoints()
        _connectedEndpoints.value = emptyMap()
        _incomingRequests.value = emptyList()
    }

    fun sendChatMessage(targetEndpointId: String?, senderName: String, text: String, isGroup: Boolean) {
        val json = JSONObject().apply {
            put("type", "CHAT")
            put("senderName", senderName)
            put("text", text)
            put("isGroup", isGroup)
            put("timestamp", System.currentTimeMillis())
        }
        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        val payload = Payload.fromBytes(bytes)

        if (isGroup || targetEndpointId == null) {
            for (endpointId in _connectedEndpoints.value.keys) {
                client.sendPayload(endpointId, payload)
            }
        } else {
            client.sendPayload(targetEndpointId, payload)
        }
    }

    fun broadcastLocation(latitude: Double, longitude: Double) {
        if (_connectedEndpoints.value.isEmpty()) return
        val json = JSONObject().apply {
            put("type", "LOCATION")
            put("lat", latitude)
            put("lng", longitude)
            put("timestamp", System.currentTimeMillis())
        }
        val payload = Payload.fromBytes(json.toString().toByteArray(Charsets.UTF_8))
        for (endpoint in _connectedEndpoints.value.keys) {
            client.sendPayload(endpoint, payload)
        }
    }

    private fun parseIncomingPayload(endpointId: String, raw: String) {
        try {
            val json = JSONObject(raw)
            when (json.optString("type")) {
                "CHAT" -> {
                    val sender = json.optString("senderName", "Peer")
                    val text = json.optString("text", "")
                    val isGroup = json.optBoolean("isGroup", false)
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    scope.launch {
                        _events.emit(NearbyEvent.MessageReceived(endpointId, sender, text, isGroup, timestamp))
                    }
                }
                "LOCATION" -> {
                    val lat = json.optDouble("lat")
                    val lng = json.optDouble("lng")
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    if (!lat.isNaN() && !lng.isNaN()) {
                        scope.launch {
                            _events.emit(NearbyEvent.LocationReceived(endpointId, lat, lng, timestamp))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SangvyaNearby", "Failed to parse payload: $raw", e)
        }
    }
}
