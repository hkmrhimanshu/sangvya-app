package com.sangvya.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = SangvyaRed,
    onPrimary = SangvyaWhite,
    primaryContainer = SangvyaRedGlow,
    onPrimaryContainer = SangvyaWhite,
    secondary = SangvyaGreyLight,
    onSecondary = SangvyaBlack,
    background = SangvyaBlack,
    onBackground = SangvyaWhite,
    surface = SangvyaSurfaceDark,
    onSurface = SangvyaWhite,
    surfaceVariant = SangvyaSurfaceCard,
    onSurfaceVariant = SangvyaGreyLight,
    outline = SangvyaGlassBorder
)

@Composable
fun SangvyaTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = SangvyaBlack.toArgb()
                window.navigationBarColor = SangvyaBlack.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
