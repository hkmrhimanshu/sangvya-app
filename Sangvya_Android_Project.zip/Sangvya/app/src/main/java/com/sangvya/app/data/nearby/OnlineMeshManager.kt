package com.sangvya.app.data.nearby

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class OnlineMeshManager(private val myUserId: String) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var listeningJob: Job? = null

    private val _currentRoom = MutableStateFlow<String?>(null)
    val currentRoom: StateFlow<String?> = _currentRoom.asStateFlow()

    private val _isOnlineConnected = MutableStateFlow(false)
    val isOnlineConnected: StateFlow<Boolean> = _isOnlineConnected.asStateFlow()

    private val _events = MutableSharedFlow<NearbyEvent>()
    val events: SharedFlow<NearbyEvent> = _events.asSharedFlow()

    fun joinRoom(roomCode: String, displayName: String) {
        val sanitized = roomCode.trim().lowercase().replace(Regex("[^a-z0-9_]"), "")
        val code = if (sanitized.isBlank()) "sangvya_mela" else sanitized
        _currentRoom.value = code
        _isOnlineConnected.value = true

        listeningJob?.cancel()
        listeningJob = scope.launch {
            listenToRoom(code, displayName)
        }

        // Announce presence
        broadcastAnnounce(displayName)
    }

    fun leaveRoom() {
        listeningJob?.cancel()
        listeningJob = null
        _currentRoom.value = null
        _isOnlineConnected.value = false
    }

    private suspend fun listenToRoom(room: String, localName: String) {
        while (scope.isActive && _isOnlineConnected.value) {
            var connection: HttpURLConnection? = null
            try {
                val url = URL("https://ntfy.sh/sangvya_mesh_$room/json")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    readTimeout = 45000
                    connectTimeout = 15000
                    doInput = true
                }

                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                while (scope.isActive && _isOnlineConnected.value) {
                    val line = reader.readLine() ?: break
                    if (line.isBlank()) continue
                    try {
                        val ntfyJson = JSONObject(line)
                        if (ntfyJson.optString("event") == "message") {
                            val msgBody = ntfyJson.optString("message", "")
                            parseRoomPayload(msgBody, localName)
                        }
                    } catch (e: Exception) {
                        Log.e("OnlineMesh", "Error parsing line: $line", e)
                    }
                }
            } catch (e: Throwable) {
                Log.w("OnlineMesh", "Connection reconnecting in 3s: ${e.message}")
                kotlinx.coroutines.delay(3000)
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun parseRoomPayload(raw: String, localName: String) {
        try {
            val json = JSONObject(raw)
            val senderId = json.optString("senderId", "")
            if (senderId == myUserId) return // Ignore self echoes

            val senderName = json.optString("senderName", "Online Peer")
            when (json.optString("type")) {
                "ANNOUNCE" -> {
                    scope.launch {
                        _events.emit(NearbyEvent.PeerConnected("online_$senderId", senderName))
                    }
                }
                "CHAT" -> {
                    val text = json.optString("text", "")
                    val isGroup = json.optBoolean("isGroup", true)
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    scope.launch {
                        _events.emit(NearbyEvent.PeerConnected("online_$senderId", senderName))
                        _events.emit(NearbyEvent.MessageReceived("online_$senderId", senderName, text, isGroup, timestamp))
                    }
                }
                "LOCATION" -> {
                    val lat = json.optDouble("lat")
                    val lng = json.optDouble("lng")
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    if (!lat.isNaN() && !lng.isNaN()) {
                        scope.launch {
                            _events.emit(NearbyEvent.PeerConnected("online_$senderId", senderName))
                            _events.emit(NearbyEvent.LocationReceived("online_$senderId", lat, lng, timestamp))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("OnlineMesh", "Error parsing payload", e)
        }
    }

    fun broadcastAnnounce(displayName: String) {
        val room = _currentRoom.value ?: return
        scope.launch {
            val json = JSONObject().apply {
                put("type", "ANNOUNCE")
                put("senderId", myUserId)
                put("senderName", displayName)
                put("timestamp", System.currentTimeMillis())
            }
            postToRoom(room, json.toString())
        }
    }

    fun broadcastLocation(displayName: String, latitude: Double, longitude: Double) {
        val room = _currentRoom.value ?: return
        scope.launch {
            val json = JSONObject().apply {
                put("type", "LOCATION")
                put("senderId", myUserId)
                put("senderName", displayName)
                put("lat", latitude)
                put("lng", longitude)
                put("timestamp", System.currentTimeMillis())
            }
            postToRoom(room, json.toString())
        }
    }

    fun sendChatMessage(displayName: String, text: String, isGroup: Boolean) {
        val room = _currentRoom.value ?: return
        scope.launch {
            val json = JSONObject().apply {
                put("type", "CHAT")
                put("senderId", myUserId)
                put("senderName", displayName)
                put("text", text)
                put("isGroup", isGroup)
                put("timestamp", System.currentTimeMillis())
            }
            postToRoom(room, json.toString())
        }
    }

    private fun postToRoom(room: String, payload: String) {
        try {
            val url = URL("https://ntfy.sh/sangvya_mesh_$room")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "text/plain; charset=utf-8")
                connectTimeout = 10000
                readTimeout = 10000
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                writer.write(payload)
                writer.flush()
            }
            val code = conn.responseCode
            conn.disconnect()
            Log.d("OnlineMesh", "Posted to room $room: code $code")
        } catch (e: Throwable) {
            Log.w("OnlineMesh", "Failed to post to room: ${e.message}")
        }
    }
}
