package com.sangvya.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sangvya.app.ui.components.GlassCard
import com.sangvya.app.ui.components.SangvyaTopBar
import com.sangvya.app.ui.theme.SangvyaBlack
import com.sangvya.app.ui.theme.SangvyaGlassBorder
import com.sangvya.app.ui.theme.SangvyaGreyDark
import com.sangvya.app.ui.theme.SangvyaGreyDim
import com.sangvya.app.ui.theme.SangvyaGreyLight
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaRedGlow
import com.sangvya.app.ui.theme.SangvyaWhite

@Composable
fun ContactScreen(
    onNavigateBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SangvyaBlack)
    ) {
        SangvyaTopBar(
            title = "CONTACT CREATOR",
            showBackButton = true,
            onBackClick = onNavigateBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card of Himanshu Bhardwaj
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 24.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(SangvyaRedGlow),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "HB",
                                color = SangvyaWhite,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Himanshu Bhardwaj",
                            color = SangvyaWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.0.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Creator & Lead Developer of Sangvya",
                            color = SangvyaRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Connect directly with Himanshu Bhardwaj for project feedback, bug reports, and upcoming features.",
                            color = SangvyaGreyLight,
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }

            item {
                Text(
                    text = "OFFICIAL SOCIAL CHANNELS",
                    color = SangvyaWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            // 1. Instagram Card
            item {
                SocialChannelCard(
                    platformName = "Instagram",
                    subtitle = "Follow & Direct Message",
                    logo = { InstagramLogo() }
                )
            }

            // 2. Facebook Card
            item {
                SocialChannelCard(
                    platformName = "Facebook",
                    subtitle = "Connect & Community",
                    logo = { FacebookLogo() }
                )
            }

            // 3. Telegram Card
            item {
                SocialChannelCard(
                    platformName = "Telegram",
                    subtitle = "Direct Channel & Updates",
                    logo = { TelegramLogo() }
                )
            }

            // Explanatory Info Card
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = SangvyaGlassBorder,
                    backgroundColor = SangvyaGreyDark.copy(alpha = 0.3f)
                ) {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = "DIRECT INTEGRATION COMING SOON",
                            color = SangvyaRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.0.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Official social handles will be linked in upcoming updates so you can connect directly with Himanshu Bhardwaj with one tap from Instagram, Facebook, and Telegram.",
                            color = SangvyaGreyDim,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun SocialChannelCard(
    platformName: String,
    subtitle: String,
    logo: @Composable () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 18.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                logo()
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = platformName,
                    color = SangvyaWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = SangvyaGreyDim,
                    fontSize = 11.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(SangvyaRed.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Coming Soon",
                    color = SangvyaRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun InstagramLogo() {
    val gradient = Brush.linearGradient(
        colors = listOf(
            Color(0xFF833AB4),
            Color(0xFFFD1D1D),
            Color(0xFFFCB045)
        )
    )
    Canvas(modifier = Modifier.size(44.dp)) {
        // Background rounded square
        drawRoundRect(
            brush = gradient,
            size = size,
            cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
        )

        val stroke = 2.5.dp.toPx()
        val pad = 10.dp.toPx()
        val camSize = size.width - 2 * pad
        // Camera outer border
        drawRoundRect(
            color = Color.White,
            topLeft = Offset(pad, pad),
            size = Size(camSize, camSize),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
            style = Stroke(width = stroke)
        )
        // Camera lens circle
        drawCircle(
            color = Color.White,
            radius = camSize * 0.25f,
            center = center,
            style = Stroke(width = stroke)
        )
        // Camera flash dot
        drawCircle(
            color = Color.White,
            radius = stroke * 0.7f,
            center = Offset(size.width - pad - 4.dp.toPx(), pad + 4.dp.toPx())
        )
    }
}

@Composable
fun FacebookLogo() {
    Canvas(modifier = Modifier.size(44.dp)) {
        // Facebook Blue circle
        drawCircle(
            color = Color(0xFF1877F2),
            radius = size.width / 2f,
            center = center
        )

        // Bold 'f' symbol in white
        val fPath = Path().apply {
            val cx = size.width * 0.52f
            val cy = size.height * 0.5f
            val w = size.width * 0.12f
            val h = size.height * 0.5f

            moveTo(cx, cy + h * 0.5f)
            lineTo(cx, cy - h * 0.15f)
            lineTo(cx + w * 1.1f, cy - h * 0.15f)
            lineTo(cx + w * 1.3f, cy - h * 0.45f)
            lineTo(cx, cy - h * 0.45f)
            lineTo(cx, cy - h * 0.65f)
            cubicTo(
                cx, cy - h * 0.85f,
                cx + w * 0.2f, cy - h * 0.95f,
                cx + w * 1.1f, cy - h * 0.95f
            )
            lineTo(cx + w * 1.1f, cy - h * 1.25f)
            lineTo(cx - w * 0.4f, cy - h * 1.25f)
            cubicTo(
                cx - w * 1.2f, cy - h * 1.25f,
                cx - w * 1.2f, cy - h * 0.7f,
                cx - w * 1.2f, cy - h * 0.45f
            )
            lineTo(cx - w * 1.8f, cy - h * 0.45f)
            lineTo(cx - w * 1.8f, cy - h * 0.15f)
            lineTo(cx - w * 1.2f, cy - h * 0.15f)
            lineTo(cx - w * 1.2f, cy + h * 0.5f)
            close()
        }
        drawPath(fPath, Color.White)
    }
}

@Composable
fun TelegramLogo() {
    Canvas(modifier = Modifier.size(44.dp)) {
        // Telegram Cyan-blue circle
        drawCircle(
            color = Color(0xFF229ED9),
            radius = size.width / 2f,
            center = center
        )

        // Paper plane in white
        val planePath = Path().apply {
            val w = size.width
            val h = size.height

            moveTo(w * 0.23f, h * 0.50f)
            lineTo(w * 0.78f, h * 0.28f)
            lineTo(w * 0.68f, h * 0.72f)
            lineTo(w * 0.50f, h * 0.62f)
            lineTo(w * 0.44f, h * 0.70f)
            lineTo(w * 0.42f, h * 0.58f)
            lineTo(w * 0.65f, h * 0.38f)
            lineTo(w * 0.34f, h * 0.55f)
            close()
        }
        drawPath(planePath, Color.White)
    }
}
