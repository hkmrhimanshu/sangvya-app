package com.sangvya.app.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sangvya.app.data.nearby.ConnectionRequest
import com.sangvya.app.data.nearby.DiscoveredPeer
import com.sangvya.app.data.repository.SangvyaRepository
import com.sangvya.app.ui.components.GlassCard
import com.sangvya.app.ui.components.SangvyaTopBar
import com.sangvya.app.ui.theme.SangvyaBlack
import com.sangvya.app.ui.theme.SangvyaGlassBorder
import com.sangvya.app.ui.theme.SangvyaGreenOnline
import com.sangvya.app.ui.theme.SangvyaGreyDark
import com.sangvya.app.ui.theme.SangvyaGreyDim
import com.sangvya.app.ui.theme.SangvyaGreyLight
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaRedGlow
import com.sangvya.app.ui.theme.SangvyaWhite

@Composable
fun NearbyScreen(
    repository: SangvyaRepository,
    onNavigateBack: () -> Unit
) {
    val isAdvertising by repository.nearbyManager.isAdvertising.collectAsState()
    val isDiscovering by repository.nearbyManager.isDiscovering.collectAsState()
    val discoveredPeers by repository.nearbyManager.discoveredPeers.collectAsState()
    val incomingRequests by repository.nearbyManager.incomingRequests.collectAsState()
    val connectedEndpoints by repository.nearbyManager.connectedEndpoints.collectAsState()
    val displayName by repository.preferences.displayNameFlow.collectAsState(initial = "Sangvya Peer")

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SangvyaBlack)
    ) {
        SangvyaTopBar(
            title = "NEARBY RADAR",
            showBackButton = true,
            onBackClick = onNavigateBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (incomingRequests.isNotEmpty()) {
                item {
                    Text(
                        text = "INCOMING REQUESTS",
                        color = SangvyaRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }

                items(incomingRequests, key = { it.endpointId }) { req ->
                    IncomingRequestCard(
                        request = req,
                        onAccept = { repository.nearbyManager.acceptConnection(req.endpointId) },
                        onReject = { repository.nearbyManager.rejectConnection(req.endpointId) }
                    )
                }
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Broadcast Presence",
                                    color = SangvyaWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isAdvertising) "Advertising as \"$displayName\"" else "Hidden from nearby devices",
                                    color = SangvyaGreyDim,
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = isAdvertising,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        repository.nearbyManager.startAdvertising(displayName)
                                    } else {
                                        repository.nearbyManager.stopAdvertising()
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SangvyaWhite,
                                    checkedTrackColor = SangvyaRed,
                                    uncheckedThumbColor = SangvyaGreyDim,
                                    uncheckedTrackColor = SangvyaGreyDark
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Scan Nearby Devices",
                                    color = SangvyaWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isDiscovering) "Scanning Bluetooth & Wi-Fi LAN..." else "Scanner inactive",
                                    color = SangvyaGreyDim,
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = isDiscovering,
                                onCheckedChange = { enable ->
                                    if (enable) {
                                        repository.nearbyManager.startDiscovery()
                                    } else {
                                        repository.nearbyManager.stopDiscovery()
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SangvyaWhite,
                                    checkedTrackColor = SangvyaRed,
                                    uncheckedThumbColor = SangvyaGreyDim,
                                    uncheckedTrackColor = SangvyaGreyDark
                                )
                            )
                        }
                    }
                }
            }

            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = SangvyaGreyDark.copy(alpha = 0.3f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .scale(if (isDiscovering || isAdvertising) pulseScale else 1.0f)
                                .clip(CircleShape)
                                .background(if (isDiscovering || isAdvertising) SangvyaRedGlow else SangvyaGreyDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.NearMe,
                                contentDescription = null,
                                tint = if (isDiscovering || isAdvertising) SangvyaRed else SangvyaGreyDim,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isDiscovering) "Searching for Sangvya peers..." else "Ready to Discover",
                                color = SangvyaWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Mesh Protocol: P2P Cluster (Max 8 peers)",
                                color = SangvyaGreyDim,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "DISCOVERED PEERS (${discoveredPeers.size})",
                    color = SangvyaWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            if (discoveredPeers.isEmpty()) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (isDiscovering) "Looking for nearby peers..." else "Scanner paused",
                                color = SangvyaGreyLight,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Ensure friends have Sangvya open with Broadcast enabled.",
                                color = SangvyaGreyDim,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            } else {
                items(discoveredPeers.values.toList(), key = { it.endpointId }) { peer ->
                    val isConnected = connectedEndpoints.containsKey(peer.endpointId)
                    DiscoveredPeerCard(
                        peer = peer,
                        isConnected = isConnected,
                        onConnect = {
                            repository.nearbyManager.requestConnection(displayName, peer.endpointId)
                        },
                        onDisconnect = {
                            repository.nearbyManager.disconnect(peer.endpointId)
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun IncomingRequestCard(
    request: ConnectionRequest,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = SangvyaRed.copy(alpha = 0.6f)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = request.endpointName,
                    color = SangvyaWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Wants to connect (Auth: ${request.authenticationDigits})",
                    color = SangvyaGreyDim,
                    fontSize = 11.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = onAccept,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SangvyaGreenOnline.copy(alpha = 0.2f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Accept",
                        tint = SangvyaGreenOnline,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = onReject,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SangvyaRed.copy(alpha = 0.2f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Reject",
                        tint = SangvyaRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DiscoveredPeerCard(
    peer: DiscoveredPeer,
    isConnected: Boolean,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(SangvyaRedGlow),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Bluetooth,
                    contentDescription = null,
                    tint = SangvyaRed,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = peer.endpointName,
                    color = SangvyaWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "ID: ${peer.endpointId}",
                    color = SangvyaGreyDim,
                    fontSize = 10.sp
                )
            }

            if (isConnected) {
                OutlinedButton(
                    onClick = onDisconnect,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SangvyaGlassBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Disconnect", color = SangvyaGreyLight, fontSize = 11.sp)
                }
            } else {
                Button(
                    onClick = onConnect,
                    colors = ButtonDefaults.buttonColors(containerColor = SangvyaRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Connect", color = SangvyaWhite, fontSize = 11.sp)
                }
            }
        }
    }
}
