package com.sangvya.app.ui.theme

import androidx.compose.ui.graphics.Color

val SangvyaBlack = Color(0xFF000000)
val SangvyaSurfaceDark = Color(0xFF0B0B0C)
val SangvyaSurfaceCard = Color(0xFF141416)
val SangvyaRed = Color(0xFFF9031D)
val SangvyaRedGlow = Color(0x33F9031D)
val SangvyaWhite = Color(0xFFFFFFFF)
val SangvyaGreyLight = Color(0xFFE2E2E2)
val SangvyaGreyDim = Color(0xFF8E8E93)
val SangvyaGreyDark = Color(0xFF242426)
val SangvyaGlassBorder = Color(0x2EFFFFFF)
val SangvyaGlassFill = Color(0x14FFFFFF)
val SangvyaGreenOnline = Color(0xFF00E676)
val SangvyaRedOffline = Color(0xFFFF5252)
