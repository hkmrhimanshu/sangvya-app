package com.sangvya.app.data.nearby

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

class P2pSocketManager(private val myUserId: String) {

    private val port = 8988
    private val scope = CoroutineScope(Dispatchers.IO)
    private var serverJob: Job? = null
    private var clientJob: Job? = null

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _connectedSockets = ConcurrentHashMap<String, Socket>()

    private val _events = MutableSharedFlow<NearbyEvent>()
    val events: SharedFlow<NearbyEvent> = _events.asSharedFlow()

    fun startServer(displayName: String) {
        if (_isServerRunning.value) return
        serverJob = scope.launch {
            var serverSocket: ServerSocket? = null
            try {
                serverSocket = ServerSocket(port)
                _isServerRunning.value = true
                Log.d("P2pSocket", "Server listening on port $port")
                while (scope.isActive && _isServerRunning.value) {
                    val socket = serverSocket.accept()
                    val peerIp = socket.inetAddress.hostAddress ?: "peer"
                    _connectedSockets[peerIp] = socket
                    launch { handleSocketConnection(socket, peerIp, displayName) }
                }
            } catch (e: Throwable) {
                Log.w("P2pSocket", "Server stopped: ${e.message}")
            } finally {
                serverSocket?.close()
                _isServerRunning.value = false
            }
        }
    }

    fun stopServer() {
        _isServerRunning.value = false
        serverJob?.cancel()
        serverJob = null
        for ((_, socket) in _connectedSockets) {
            try { socket.close() } catch (e: Exception) {}
        }
        _connectedSockets.clear()
    }

    fun connectToHost(hostIp: String, displayName: String) {
        clientJob?.cancel()
        clientJob = scope.launch {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(hostIp, port), 5000)
                _connectedSockets[hostIp] = socket
                handleSocketConnection(socket, hostIp, displayName)
            } catch (e: Throwable) {
                Log.w("P2pSocket", "Failed to connect to host $hostIp: ${e.message}")
            }
        }
    }

    private suspend fun handleSocketConnection(socket: Socket, peerKey: String, localName: String) {
        val endpointId = "socket_$peerKey"
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val writer = PrintWriter(socket.getOutputStream(), true)

            // Announce presence
            val announce = JSONObject().apply {
                put("type", "ANNOUNCE")
                put("senderId", myUserId)
                put("senderName", localName)
                put("timestamp", System.currentTimeMillis())
            }
            writer.println(announce.toString())

            while (scope.isActive && !socket.isClosed) {
                val line = reader.readLine() ?: break
                if (line.isBlank()) continue
                parseSocketMessage(endpointId, line)
            }
        } catch (e: Throwable) {
            Log.w("P2pSocket", "Connection lost with $peerKey: ${e.message}")
        } finally {
            _connectedSockets.remove(peerKey)
            try { socket.close() } catch (e: Exception) {}
            scope.launch {
                _events.emit(NearbyEvent.PeerDisconnected(endpointId))
            }
        }
    }

    private fun parseSocketMessage(endpointId: String, raw: String) {
        try {
            val json = JSONObject(raw)
            val senderId = json.optString("senderId", "")
            if (senderId == myUserId) return

            val senderName = json.optString("senderName", "Socket Peer")
            when (json.optString("type")) {
                "ANNOUNCE" -> {
                    scope.launch {
                        _events.emit(NearbyEvent.PeerConnected(endpointId, senderName))
                    }
                }
                "CHAT" -> {
                    val text = json.optString("text", "")
                    val isGroup = json.optBoolean("isGroup", false)
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    scope.launch {
                        _events.emit(NearbyEvent.PeerConnected(endpointId, senderName))
                        _events.emit(NearbyEvent.MessageReceived(endpointId, senderName, text, isGroup, timestamp))
                    }
                }
                "LOCATION" -> {
                    val lat = json.optDouble("lat")
                    val lng = json.optDouble("lng")
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    if (!lat.isNaN() && !lng.isNaN()) {
                        scope.launch {
                            _events.emit(NearbyEvent.PeerConnected(endpointId, senderName))
                            _events.emit(NearbyEvent.LocationReceived(endpointId, lat, lng, timestamp))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("P2pSocket", "Error parsing socket message", e)
        }
    }

    fun broadcastLocation(displayName: String, latitude: Double, longitude: Double) {
        if (_connectedSockets.isEmpty()) return
        scope.launch {
            val json = JSONObject().apply {
                put("type", "LOCATION")
                put("senderId", myUserId)
                put("senderName", displayName)
                put("lat", latitude)
                put("lng", longitude)
                put("timestamp", System.currentTimeMillis())
            }
            sendRawToAll(json.toString())
        }
    }

    fun sendChatMessage(displayName: String, text: String, isGroup: Boolean) {
        if (_connectedSockets.isEmpty()) return
        scope.launch {
            val json = JSONObject().apply {
                put("type", "CHAT")
                put("senderId", myUserId)
                put("senderName", displayName)
                put("text", text)
                put("isGroup", isGroup)
                put("timestamp", System.currentTimeMillis())
            }
            sendRawToAll(json.toString())
        }
    }

    private fun sendRawToAll(payload: String) {
        for ((_, socket) in _connectedSockets) {
            try {
                if (!socket.isClosed) {
                    val writer = PrintWriter(socket.getOutputStream(), true)
                    writer.println(payload)
                }
            } catch (e: Exception) {
                Log.w("P2pSocket", "Error writing to socket: ${e.message}")
            }
        }
    }
}
