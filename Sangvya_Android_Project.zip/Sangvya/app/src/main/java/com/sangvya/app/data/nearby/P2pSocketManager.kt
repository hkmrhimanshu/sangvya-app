package com.sangvya.app.data.nearby

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

class P2pSocketManager(
    private val context: Context,
    private val myUserId: String
) {

    private val port = 8988
    private val scope = CoroutineScope(Dispatchers.IO)
    private var serverJob: Job? = null
    private var clientJob: Job? = null
    private var clientSocket: Socket? = null

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _isClientConnected = MutableStateFlow(false)
    val isClientConnected: StateFlow<Boolean> = _isClientConnected.asStateFlow()

    private val _isConnecting = MutableStateFlow(false)
    val isConnecting: StateFlow<Boolean> = _isConnecting.asStateFlow()

    private val _connectedHostIp = MutableStateFlow<String?>(null)
    val connectedHostIp: StateFlow<String?> = _connectedHostIp.asStateFlow()

    private val _serverIp = MutableStateFlow("192.168.43.1")
    val serverIp: StateFlow<String> = _serverIp.asStateFlow()

    private val _connectedSockets = ConcurrentHashMap<String, Socket>()

    private val _events = MutableSharedFlow<NearbyEvent>()
    val events: SharedFlow<NearbyEvent> = _events.asSharedFlow()

    fun detectGatewayIp(): String {
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val dhcp = wm?.dhcpInfo
            if (dhcp != null && dhcp.gateway != 0) {
                val ip = dhcp.gateway
                val ipStr = "${ip and 0xFF}.${(ip shr 8) and 0xFF}.${(ip shr 16) and 0xFF}.${(ip shr 24) and 0xFF}"
                if (ipStr.isNotBlank() && ipStr != "0.0.0.0") {
                    return ipStr
                }
            }
        } catch (e: Exception) {
            Log.w("P2pSocket", "Could not read DHCP gateway: ${e.message}")
        }
        return "192.168.43.1"
    }

    private fun detectLocalIp(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            for (intf in interfaces) {
                for (addr in intf.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val host = addr.hostAddress ?: ""
                        if (host.startsWith("192.168.") || host.startsWith("10.") || host.startsWith("172.")) {
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("P2pSocket", "Could not detect local IP: ${e.message}")
        }
        return "192.168.43.1"
    }

    fun startServer(displayName: String) {
        if (_isServerRunning.value) return
        _serverIp.value = detectLocalIp()

        serverJob = scope.launch {
            var serverSocket: ServerSocket? = null
            try {
                serverSocket = ServerSocket(port)
                _isServerRunning.value = true
                Log.d("P2pSocket", "Hotspot Server listening on port $port")
                while (scope.isActive && _isServerRunning.value) {
                    val socket = serverSocket.accept()
                    val peerIp = socket.inetAddress.hostAddress ?: "peer"
                    _connectedSockets[peerIp] = socket
                    launch { handleSocketConnection(socket, peerIp, displayName) }
                }
            } catch (e: Throwable) {
                Log.w("P2pSocket", "Hotspot Server stopped: ${e.message}")
            } finally {
                serverSocket?.close()
                _isServerRunning.value = false
            }
        }
    }

    fun stopServer() {
        _isServerRunning.value = false
        serverJob?.cancel()
        serverJob = null
        for ((_, socket) in _connectedSockets) {
            try { socket.close() } catch (e: Exception) {}
        }
        _connectedSockets.clear()
    }

    fun connectToHost(targetIp: String, displayName: String) {
        val hostIp = targetIp.trim().ifBlank { detectGatewayIp() }
        clientJob?.cancel()
        _isConnecting.value = true

        clientJob = scope.launch {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(hostIp, port), 4000)
                clientSocket = socket
                _connectedSockets[hostIp] = socket
                _isClientConnected.value = true
                _isConnecting.value = false
                _connectedHostIp.value = hostIp

                handleSocketConnection(socket, hostIp, displayName)
            } catch (e: Throwable) {
                Log.w("P2pSocket", "Failed to connect to host $hostIp: ${e.message}")
                _isConnecting.value = false
                _isClientConnected.value = false
                _connectedHostIp.value = null
            }
        }
    }

    fun disconnectClient() {
        _isConnecting.value = false
        _isClientConnected.value = false
        _connectedHostIp.value = null
        clientJob?.cancel()
        clientJob = null
        try {
            clientSocket?.close()
        } catch (e: Exception) {}
        clientSocket = null
    }

    private suspend fun handleSocketConnection(socket: Socket, peerKey: String, localName: String) {
        val endpointId = "socket_$peerKey"
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val writer = PrintWriter(socket.getOutputStream(), true)

            // Immediately send announce packet
            val announce = JSONObject().apply {
                put("type", "ANNOUNCE")
                put("senderId", myUserId)
                put("senderName", localName)
                put("timestamp", System.currentTimeMillis())
            }
            writer.println(announce.toString())

            while (scope.isActive && !socket.isClosed) {
                val line = reader.readLine() ?: break
                if (line.isBlank()) continue
                parseSocketMessage(endpointId, line)
            }
        } catch (e: Throwable) {
            Log.w("P2pSocket", "Connection lost with $peerKey: ${e.message}")
        } finally {
            _connectedSockets.remove(peerKey)
            try { socket.close() } catch (e: Exception) {}
            if (peerKey == _connectedHostIp.value) {
                _isClientConnected.value = false
                _connectedHostIp.value = null
            }
            scope.launch {
                _events.emit(NearbyEvent.PeerDisconnected(endpointId))
            }
        }
    }

    private fun parseSocketMessage(endpointId: String, raw: String) {
        try {
            val json = JSONObject(raw)
            val senderId = json.optString("senderId", "")
            if (senderId == myUserId) return

            val senderName = json.optString("senderName", "Hotspot Peer")
            when (json.optString("type")) {
                "ANNOUNCE" -> {
                    scope.launch {
                        _events.emit(NearbyEvent.PeerConnected(endpointId, senderName))
                    }
                }
                "CHAT" -> {
                    val text = json.optString("text", "")
                    val isGroup = json.optBoolean("isGroup", false)
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    scope.launch {
                        _events.emit(NearbyEvent.PeerConnected(endpointId, senderName))
                        _events.emit(NearbyEvent.MessageReceived(endpointId, senderName, text, isGroup, timestamp))
                    }
                }
                "LOCATION" -> {
                    val lat = json.optDouble("lat")
                    val lng = json.optDouble("lng")
                    val timestamp = json.optLong("timestamp", System.currentTimeMillis())
                    if (!lat.isNaN() && !lng.isNaN()) {
                        scope.launch {
                            _events.emit(NearbyEvent.PeerConnected(endpointId, senderName))
                            _events.emit(NearbyEvent.LocationReceived(endpointId, lat, lng, timestamp))
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("P2pSocket", "Error parsing socket message", e)
        }
    }

    fun broadcastLocation(displayName: String, latitude: Double, longitude: Double) {
        if (_connectedSockets.isEmpty()) return
        scope.launch {
            val json = JSONObject().apply {
                put("type", "LOCATION")
                put("senderId", myUserId)
                put("senderName", displayName)
                put("lat", latitude)
                put("lng", longitude)
                put("timestamp", System.currentTimeMillis())
            }
            sendRawToAll(json.toString())
        }
    }

    fun sendChatMessage(displayName: String, text: String, isGroup: Boolean) {
        if (_connectedSockets.isEmpty()) return
        scope.launch {
            val json = JSONObject().apply {
                put("type", "CHAT")
                put("senderId", myUserId)
                put("senderName", displayName)
                put("text", text)
                put("isGroup", isGroup)
                put("timestamp", System.currentTimeMillis())
            }
            sendRawToAll(json.toString())
        }
    }

    private fun sendRawToAll(payload: String) {
        for ((_, socket) in _connectedSockets) {
            try {
                if (!socket.isClosed) {
                    val writer = PrintWriter(socket.getOutputStream(), true)
                    writer.println(payload)
                }
            } catch (e: Exception) {
                Log.w("P2pSocket", "Error writing to socket: ${e.message}")
            }
        }
    }
}
