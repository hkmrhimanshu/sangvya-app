package com.sangvya.app.ui.screens

import android.graphics.Bitmap
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.sangvya.app.data.local.entity.FriendEntity
import com.sangvya.app.data.model.ConnectionStatus
import com.sangvya.app.data.model.QrPayload
import com.sangvya.app.data.model.QrType
import com.sangvya.app.data.qr.QrCodeAnalyzer
import com.sangvya.app.data.qr.QrCodeGenerator
import com.sangvya.app.data.repository.SangvyaRepository
import com.sangvya.app.ui.components.GlassCard
import com.sangvya.app.ui.components.SangvyaTopBar
import com.sangvya.app.ui.theme.SangvyaBlack
import com.sangvya.app.ui.theme.SangvyaGlassBorder
import com.sangvya.app.ui.theme.SangvyaGreenOnline
import com.sangvya.app.ui.theme.SangvyaGreyDark
import com.sangvya.app.ui.theme.SangvyaGreyDim
import com.sangvya.app.ui.theme.SangvyaGreyLight
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaWhite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun QrHubScreen(
    repository: SangvyaRepository,
    onNavigateBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("My Code", "Group Invite", "Scan Code")

    val userId by repository.preferences.userIdFlow.collectAsState(initial = "sangvya_user_01")
    val displayName by repository.preferences.displayNameFlow.collectAsState(initial = "Sangvya Peer")
    val serverIp by repository.p2pSocketManager.serverIp.collectAsState()

    var scannedPayload by remember { mutableStateOf<QrPayload?>(null) }
    var scanError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SangvyaBlack)
    ) {
        SangvyaTopBar(
            title = "QR CONNECTION HUB",
            showBackButton = true,
            onBackClick = onNavigateBack
        )

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SangvyaBlack,
            contentColor = SangvyaWhite,
            indicator = { tabPositions ->
                TabRowDefaults.Indicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = SangvyaRed,
                    height = 2.dp
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = {
                        selectedTab = index
                        scannedPayload = null
                        scanError = null
                    },
                    text = {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) SangvyaWhite else SangvyaGreyDim
                        )
                    }
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            when (selectedTab) {
                0 -> MyQrCodeTab(
                    repository = repository,
                    userId = userId,
                    displayName = displayName,
                    serverIp = serverIp
                )
                1 -> GroupQrCodeTab(
                    repository = repository,
                    userId = userId,
                    displayName = displayName,
                    serverIp = serverIp
                )
                2 -> ScannerTab(
                    scannedPayload = scannedPayload,
                    scanError = scanError,
                    onPayloadScanned = { payload ->
                        scannedPayload = payload
                        scanError = null
                    },
                    onError = { err ->
                        scanError = err
                    },
                    onConnectRequest = { payload ->
                        CoroutineScope(Dispatchers.IO).launch {
                            val friendId = payload.userId
                            val endpointId = "online_$friendId"

                            // 1. Save friend as CONNECTED immediately
                            val newFriend = FriendEntity(
                                id = friendId,
                                endpointId = endpointId,
                                displayName = payload.displayName,
                                status = ConnectionStatus.CONNECTED.name,
                                lastSeenTimestamp = System.currentTimeMillis()
                            )
                            repository.database.friendDao().insertOrUpdate(newFriend)

                            // 2. Join the QR token room (where Phone A is actively listening)
                            val room = payload.token.ifBlank { "sangvya_mela" }
                            val myName = repository.preferences.displayNameFlow.first()
                            repository.onlineMeshManager.joinRoom(room, myName)

                            // 3. Immediately announce and broadcast current GPS coordinates
                            repository.onlineMeshManager.broadcastAnnounce(myName)
                            val loc = repository.locationHelper.currentLocation.value
                            if (loc != null) {
                                repository.onlineMeshManager.broadcastLocation(myName, loc.latitude, loc.longitude)
                            }

                            // 4. If host IP provided, connect socket as well
                            if (payload.hostIp.isNotBlank()) {
                                repository.p2pSocketManager.connectToHost(payload.hostIp, myName)
                            }

                            repository.nearbyManager.startDiscovery()
                        }
                        scannedPayload = null
                        onNavigateBack()
                    },
                    onDismiss = {
                        scannedPayload = null
                        scanError = null
                    }
                )
            }
        }
    }
}

@Composable
fun MyQrCodeTab(
    repository: SangvyaRepository,
    userId: String,
    displayName: String,
    serverIp: String
) {
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val personalRoom = remember(userId) { "user_" + userId.take(8).lowercase() }

    // Crucial fix: Phone A MUST listen in personalRoom so when Phone B scans, they connect immediately!
    DisposableEffect(personalRoom, displayName) {
        repository.onlineMeshManager.joinRoom(personalRoom, displayName)
        onDispose {
            // keep listening for peer traffic
        }
    }

    LaunchedEffect(userId, displayName, serverIp) {
        val payload = QrPayload(
            protocol = "SANGVYA",
            version = "4.0",
            type = QrType.INDIVIDUAL,
            userId = userId,
            displayName = displayName,
            token = personalRoom,
            hostIp = serverIp
        )
        qrBitmap = QrCodeGenerator.generateQrBitmap(payload.toJson(), 600, 600)
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "PERSONAL CONNECTION QR",
                color = SangvyaWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Have a friend scan this code to link devices instantly with live GPS tracking.",
                color = SangvyaGreyDim,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (qrBitmap != null) {
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(SangvyaWhite)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = qrBitmap!!.asImageBitmap(),
                        contentDescription = "My Sangvya QR Code",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .background(SangvyaGreyDark),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Generating QR...", color = SangvyaGreyDim)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = displayName,
                color = SangvyaWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(androidx.compose.foundation.shape.CircleShape)
                        .background(SangvyaGreenOnline)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Pairing Channel: $personalRoom",
                    color = SangvyaGreenOnline,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun GroupQrCodeTab(
    repository: SangvyaRepository,
    userId: String,
    displayName: String,
    serverIp: String
) {
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val groupRoom = remember(userId) { "group_" + userId.take(6).lowercase() }

    DisposableEffect(groupRoom, displayName) {
        repository.onlineMeshManager.joinRoom(groupRoom, displayName)
        onDispose {}
    }

    LaunchedEffect(userId, displayName, serverIp) {
        val payload = QrPayload(
            protocol = "SANGVYA",
            version = "4.0",
            type = QrType.GROUP,
            userId = userId,
            displayName = "$displayName's Mesh Group",
            token = groupRoom,
            hostIp = serverIp
        )
        qrBitmap = QrCodeGenerator.generateQrBitmap(payload.toJson(), 600, 600)
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "GROUP INVITATION QR",
                color = SangvyaRed,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Invite friends to link together in an encrypted spatial radar cluster.",
                color = SangvyaGreyDim,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (qrBitmap != null) {
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(SangvyaWhite)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = qrBitmap!!.asImageBitmap(),
                        contentDescription = "Sangvya Group QR Code",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Mesh Group: $displayName",
                color = SangvyaWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(androidx.compose.foundation.shape.CircleShape)
                        .background(SangvyaGreenOnline)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Room: $groupRoom",
                    color = SangvyaGreenOnline,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun ScannerTab(
    scannedPayload: QrPayload?,
    scanError: String?,
    onPayloadScanned: (QrPayload) -> Unit,
    onError: (String) -> Unit,
    onConnectRequest: (QrPayload) -> Unit,
    onDismiss: () -> Unit
) {
    val lifecycleOwner = LocalLifecycleOwner.current

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val imageAnalyzer = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                        .also { analysis ->
                            analysis.setAnalyzer(
                                ContextCompat.getMainExecutor(ctx),
                                QrCodeAnalyzer { rawString ->
                                    val payload = QrPayload.fromJson(rawString)
                                    if (payload != null) {
                                        onPayloadScanned(payload)
                                    } else {
                                        onError("Not a valid Sangvya QR code.")
                                    }
                                }
                            )
                        }

                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageAnalyzer
                        )
                    } catch (e: Exception) {
                        onError("Camera initialization failed: ${e.message}")
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            }
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .border(2.dp, SangvyaRed, RoundedCornerShape(16.dp))
            )
        }

        if (scannedPayload != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SangvyaBlack.copy(alpha = 0.85f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = SangvyaRed
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "PEER VERIFIED",
                            color = SangvyaRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = scannedPayload.displayName,
                            color = SangvyaWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sangvya v${scannedPayload.version} • Type: ${scannedPayload.type.name}",
                            color = SangvyaGreyDim,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { onConnectRequest(scannedPayload) },
                                colors = ButtonDefaults.buttonColors(containerColor = SangvyaRed),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Connect Peer", color = SangvyaWhite)
                            }
                            OutlinedButton(
                                onClick = onDismiss,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SangvyaGlassBorder),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Cancel", color = SangvyaGreyLight)
                            }
                        }
                    }
                }
            }
        }

        if (scanError != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(24.dp)
            ) {
                GlassCard(
                    backgroundColor = SangvyaRed.copy(alpha = 0.2f),
                    borderColor = SangvyaRed
                ) {
                    Text(
                        text = scanError,
                        color = SangvyaWhite,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
