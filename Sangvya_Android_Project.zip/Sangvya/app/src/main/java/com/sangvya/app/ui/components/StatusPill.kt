package com.sangvya.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sangvya.app.data.model.ConnectionStatus
import com.sangvya.app.ui.theme.SangvyaGreenOnline
import com.sangvya.app.ui.theme.SangvyaGreyDark
import com.sangvya.app.ui.theme.SangvyaGreyDim
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaRedOffline
import com.sangvya.app.ui.theme.SangvyaWhite

@Composable
fun StatusPill(
    status: ConnectionStatus,
    modifier: Modifier = Modifier
) {
    val (color, label) = when (status) {
        ConnectionStatus.CONNECTED -> SangvyaGreenOnline to "CONNECTED"
        ConnectionStatus.CONNECTING -> SangvyaRed to "LINKING..."
        ConnectionStatus.DISCONNECTED -> SangvyaGreyDim to "OFFLINE"
        ConnectionStatus.BLOCKED -> SangvyaRedOffline to "BLOCKED"
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(SangvyaGreyDark.copy(alpha = 0.6f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            color = SangvyaWhite,
            fontSize = 10.sp,
            letterSpacing = 0.5.sp
        )
    }
}
