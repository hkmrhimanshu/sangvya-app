package com.sangvya.app.data.repository

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.sangvya.app.data.local.AppDatabase
import com.sangvya.app.data.local.entity.ChatMessageEntity
import com.sangvya.app.data.local.entity.FriendEntity
import com.sangvya.app.data.location.LocationHelper
import com.sangvya.app.data.location.UserLocation
import com.sangvya.app.data.model.ChatMessage
import com.sangvya.app.data.model.ConnectionStatus
import com.sangvya.app.data.model.DistanceAlertSettings
import com.sangvya.app.data.model.Friend
import com.sangvya.app.data.model.MessageStatus
import com.sangvya.app.data.nearby.DiscoveredPeer
import com.sangvya.app.data.nearby.NearbyEvent
import com.sangvya.app.data.nearby.NearbyManager
import com.sangvya.app.data.preference.UserPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID

class SangvyaRepository(
    private val context: Context,
    val database: AppDatabase,
    val preferences: UserPreferencesRepository,
    val nearbyManager: NearbyManager,
    val locationHelper: LocationHelper
) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private val notifiedAlerts = mutableSetOf<String>()
    @Volatile
    private var isLocationSharingEnabled = true

    val allFriendsFlow: Flow<List<Friend>> = database.friendDao().getAllFriendsFlow()
        .map { list -> list.map { it.toModel() } }

    val connectedFriendsFlow: Flow<List<Friend>> = database.friendDao().getConnectedFriendsFlow()
        .map { list -> list.map { it.toModel() } }

    val userLocation: StateFlow<UserLocation?> = locationHelper.currentLocation

    private val _proximityAlertEvents = MutableSharedFlow<String>()
    val proximityAlertEvents: SharedFlow<String> = _proximityAlertEvents.asSharedFlow()

    init {
        scope.launch {
            preferences.locationSharingFlow.collect { isLocationSharingEnabled = it }
        }
        scope.launch {
            nearbyManager.events.collect { event ->
                when (event) {
                    is NearbyEvent.PeerConnected -> handlePeerConnected(event.endpointId, event.endpointName)
                    is NearbyEvent.PeerDisconnected -> handlePeerDisconnected(event.endpointId)
                    is NearbyEvent.MessageReceived -> handleMessageReceived(event.endpointId, event.senderName, event.text, event.isGroup, event.timestamp)
                    is NearbyEvent.LocationReceived -> handleLocationReceived(event.endpointId, event.latitude, event.longitude, event.timestamp)
                }
            }
        }

        scope.launch {
            locationHelper.currentLocation.collect { loc ->
                if (loc != null) {
                    if (isLocationSharingEnabled) {
                        nearbyManager.broadcastLocation(loc.latitude, loc.longitude)
                    }
                    recalculateFriendDistances(loc)
                }
            }
        }
    }

    private suspend fun handlePeerConnected(endpointId: String, peerName: String) {
        val existing = database.friendDao().getFriendByEndpointId(endpointId)
        if (existing != null) {
            database.friendDao().updateStatus(existing.id, ConnectionStatus.CONNECTED.name)
        } else {
            val friendId = "peer_$endpointId"
            val newFriend = FriendEntity(
                id = friendId,
                endpointId = endpointId,
                displayName = peerName,
                status = ConnectionStatus.CONNECTED.name,
                lastSeenTimestamp = System.currentTimeMillis()
            )
            database.friendDao().insertOrUpdate(newFriend)
        }
    }

    private suspend fun handlePeerDisconnected(endpointId: String) {
        val existing = database.friendDao().getFriendByEndpointId(endpointId)
        if (existing != null) {
            database.friendDao().updateStatus(existing.id, ConnectionStatus.DISCONNECTED.name)
        }
    }

    private suspend fun handleMessageReceived(
        endpointId: String,
        senderName: String,
        text: String,
        isGroup: Boolean,
        timestamp: Long
    ) {
        val existingFriend = database.friendDao().getFriendByEndpointId(endpointId)
        val peerId = existingFriend?.id ?: "peer_$endpointId"

        val chatMessage = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            peerId = peerId,
            senderName = senderName,
            content = text,
            timestamp = timestamp,
            isIncoming = true,
            isGroup = isGroup,
            status = MessageStatus.RECEIVED.name
        )
        database.chatMessageDao().insertMessage(chatMessage)
    }

    private suspend fun handleLocationReceived(
        endpointId: String,
        lat: Double,
        lng: Double,
        timestamp: Long
    ) {
        val friend = database.friendDao().getFriendByEndpointId(endpointId) ?: return
        val currentLoc = locationHelper.currentLocation.value

        var dist: Float? = null
        var bearing: Float? = null

        if (currentLoc != null) {
            dist = LocationHelper.calculateDistanceMeters(
                currentLoc.latitude, currentLoc.longitude,
                lat, lng
            )
            bearing = LocationHelper.calculateBearingDegrees(
                currentLoc.latitude, currentLoc.longitude,
                lat, lng
            )
            checkProximityAlert(friend.displayName, friend.id, dist)
        }

        database.friendDao().updateLocation(friend.id, dist, bearing, lat, lng, timestamp)
    }

    private suspend fun recalculateFriendDistances(userLoc: UserLocation) {
        val connected = database.friendDao().getConnectedFriendsFlow().first()
        for (f in connected) {
            if (f.latitude != null && f.longitude != null) {
                val dist = LocationHelper.calculateDistanceMeters(
                    userLoc.latitude, userLoc.longitude,
                    f.latitude, f.longitude
                )
                val bearing = LocationHelper.calculateBearingDegrees(
                    userLoc.latitude, userLoc.longitude,
                    f.latitude, f.longitude
                )
                val prevDist = f.distanceMeters ?: -1f
                if (prevDist < 0f || kotlin.math.abs(dist - prevDist) >= 1.5f) {
                    database.friendDao().updateLocation(f.id, dist, bearing, f.latitude, f.longitude, System.currentTimeMillis())
                }
                checkProximityAlert(f.displayName, f.id, dist)
            }
        }
    }

    private suspend fun checkProximityAlert(name: String, friendId: String, distance: Float) {
        val settings = preferences.alertSettingsFlow.first()
        if (!settings.alertsEnabled) return

        if (distance <= settings.thresholdMeters) {
            if (!notifiedAlerts.contains(friendId)) {
                notifiedAlerts.add(friendId)
                triggerHapticFeedback(settings)
                _proximityAlertEvents.emit("$name is nearby (${distance.toInt()}m)!")
            }
        } else {
            notifiedAlerts.remove(friendId)
        }
    }

    private fun triggerHapticFeedback(settings: DistanceAlertSettings) {
        if (!settings.vibrationEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(300)
            }
        } catch (e: Exception) {}
    }

    suspend fun sendDirectMessage(friendId: String, text: String) {
        val myName = preferences.displayNameFlow.first()
        val friend = database.friendDao().getFriendById(friendId) ?: return

        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            peerId = friendId,
            senderName = myName,
            content = text,
            timestamp = System.currentTimeMillis(),
            isIncoming = false,
            isGroup = false,
            status = MessageStatus.SENT.name
        )
        database.chatMessageDao().insertMessage(msg)

        if (friend.endpointId.isNotEmpty()) {
            nearbyManager.sendChatMessage(friend.endpointId, myName, text, false)
        }
    }

    suspend fun sendGroupMessage(text: String) {
        val myName = preferences.displayNameFlow.first()
        val msg = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            peerId = "group_mesh",
            senderName = myName,
            content = text,
            timestamp = System.currentTimeMillis(),
            isIncoming = false,
            isGroup = true,
            status = MessageStatus.SENT.name
        )
        database.chatMessageDao().insertMessage(msg)
        nearbyManager.sendChatMessage(null, myName, text, true)
    }

    fun getDirectMessages(peerId: String): Flow<List<ChatMessage>> {
        return database.chatMessageDao().getDirectMessagesFlow(peerId).map { list ->
            list.map { it.toModel() }
        }
    }

    fun getGroupMessages(): Flow<List<ChatMessage>> {
        return database.chatMessageDao().getGroupMessagesFlow().map { list ->
            list.map { it.toModel() }
        }
    }

    suspend fun disconnectFriend(friendId: String) {
        val friend = database.friendDao().getFriendById(friendId) ?: return
        if (friend.endpointId.isNotEmpty()) {
            nearbyManager.disconnect(friend.endpointId)
        }
        database.friendDao().updateStatus(friendId, ConnectionStatus.DISCONNECTED.name)
    }

    suspend fun blockFriend(friendId: String) {
        disconnectFriend(friendId)
        database.friendDao().updateStatus(friendId, ConnectionStatus.BLOCKED.name)
        preferences.blockUser(friendId)
    }

    suspend fun unblockFriend(friendId: String) {
        database.friendDao().updateStatus(friendId, ConnectionStatus.DISCONNECTED.name)
        preferences.unblockUser(friendId)
    }
}
