package com.sangvya.app.data.model

enum class ConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    BLOCKED
}

data class Friend(
    val id: String,
    val endpointId: String = "",
    val displayName: String,
    val status: ConnectionStatus = ConnectionStatus.DISCONNECTED,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val distanceMeters: Float? = null,
    val bearingDegrees: Float? = null,
    val isLocationShared: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
) {
    val formattedDistance: String
        get() {
            val dist = distanceMeters ?: return "Location unavailable"
            return if (dist < 1000f) {
                "${dist.toInt()} m away"
            } else {
                "%.1f km away".format(dist / 1000f)
            }
        }
}
