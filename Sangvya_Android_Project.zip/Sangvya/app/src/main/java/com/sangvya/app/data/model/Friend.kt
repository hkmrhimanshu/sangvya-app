package com.sangvya.app.data.model

enum class ConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    BLOCKED
}

data class Friend(
    val id: String,
    val endpointId: String = "",
    val displayName: String,
    val status: ConnectionStatus = ConnectionStatus.DISCONNECTED,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val distanceMeters: Float? = null,
    val bearingDegrees: Float? = null,
    val isLocationShared: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
) {
    val formattedDistance: String
        get() {
            val dist = distanceMeters
            if (dist != null) {
                return if (dist < 1000f) {
                    "${dist.toInt()} m away"
                } else {
                    "%.1f km away".format(dist / 1000f)
                }
            }
            if (latitude != null && longitude != null) {
                return "Live GPS Active"
            }
            return "Location unavailable"
        }

    fun getRelativeDirection(userHeading: Float = 0f): String {
        val dist = distanceMeters
        if (dist != null) {
            val bearing = bearingDegrees ?: return formattedDistance
            val distStr = if (dist < 1000f) "${dist.toInt()}m" else "%.1fkm".format(dist / 1000f)
            val diff = (bearing - userHeading + 360f) % 360f

            val dirStr = when (diff) {
                in 45f..135f -> "Right (दाएँ)"
                in 135f..225f -> "Behind (पीछे)"
                in 225f..315f -> "Left (बाएँ)"
                else -> "Ahead (आगे)"
            }

            return "$distStr • $dirStr"
        }

        if (latitude != null && longitude != null) {
            return "Live GPS Linked (Calculating distance...)"
        }

        return "Location unavailable"
    }
}
