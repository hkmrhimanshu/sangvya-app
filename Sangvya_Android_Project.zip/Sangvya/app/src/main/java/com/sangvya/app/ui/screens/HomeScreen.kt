package com.sangvya.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sangvya.app.R
import com.sangvya.app.data.model.Friend
import com.sangvya.app.data.repository.SangvyaRepository
import com.sangvya.app.ui.components.GlassCard
import com.sangvya.app.ui.components.SangvyaTopBar
import com.sangvya.app.ui.components.StatusPill
import com.sangvya.app.ui.theme.SangvyaBlack
import com.sangvya.app.ui.theme.SangvyaGlassBorder
import com.sangvya.app.ui.theme.SangvyaGreenOnline
import com.sangvya.app.ui.theme.SangvyaGreyDark
import com.sangvya.app.ui.theme.SangvyaGreyDim
import com.sangvya.app.ui.theme.SangvyaGreyLight
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaRedGlow
import com.sangvya.app.ui.theme.SangvyaWhite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    repository: SangvyaRepository,
    onNavigateToNearby: () -> Unit,
    onNavigateToQr: () -> Unit,
    onNavigateToRadar: () -> Unit,
    onNavigateToGroupChat: () -> Unit,
    onNavigateToPrivateChat: (String) -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val connectedFriends by repository.connectedFriendsFlow.collectAsState(initial = emptyList())
    val userLocation by repository.userLocation.collectAsState()
    val displayName by repository.preferences.displayNameFlow.collectAsState(initial = "Sangvya Peer")
    val locationSharing by repository.preferences.locationSharingFlow.collectAsState(initial = true)
    val alertSettings by repository.preferences.alertSettingsFlow.collectAsState(initial = null)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SangvyaBlack)
    ) {
        SangvyaTopBar(
            title = "SANGVYA",
            subtitle = "v2.0",
            actions = {
                IconButton(onClick = onNavigateToSettings) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = SangvyaWhite
                    )
                }
            }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.sangvya_logo_header),
                            contentDescription = "User Avatar",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = displayName,
                                color = SangvyaWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (locationSharing) SangvyaGreenOnline else SangvyaGreyDim)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (locationSharing) "Live GPS Active" else "Location Paused",
                                    color = SangvyaGreyDim,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        IconButton(onClick = onNavigateToQr) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "My QR Code",
                                tint = SangvyaRed
                            )
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        icon = Icons.Default.NearMe,
                        label = "Nearby",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToNearby
                    )
                    QuickActionTile(
                        icon = Icons.Default.LocationOn,
                        label = "Radar",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToRadar
                    )
                    QuickActionTile(
                        icon = Icons.Default.Group,
                        label = "Group",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToGroupChat
                    )
                    QuickActionTile(
                        icon = Icons.Default.QrCodeScanner,
                        label = "Scan QR",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToQr
                    )
                }
            }

            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = SangvyaGreyDark.copy(alpha = 0.35f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        MetricColumn(
                            value = "${connectedFriends.size} / 8",
                            label = "CONNECTED PEERS"
                        )
                        MetricColumn(
                            value = if (alertSettings?.alertsEnabled == true) "${alertSettings?.thresholdMeters?.toInt()}m" else "OFF",
                            label = "PROXIMITY ALERT"
                        )
                        MetricColumn(
                            value = if (userLocation != null) "%.2fm".format(userLocation!!.accuracy) else "SEARCHING",
                            label = "GPS PRECISION"
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CONNECTED PEERS (${connectedFriends.size})",
                        color = SangvyaWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    if (connectedFriends.isNotEmpty()) {
                        Text(
                            text = "Tap to chat",
                            color = SangvyaGreyDim,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (connectedFriends.isEmpty()) {
                item {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.NearMe,
                                contentDescription = null,
                                tint = SangvyaRed.copy(alpha = 0.7f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "No Connected Peers",
                                color = SangvyaWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Scan a friend's QR code or start discovery on the Nearby radar to link 2 to 8 peers.",
                                color = SangvyaGreyDim,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = onNavigateToNearby,
                                    colors = ButtonDefaults.buttonColors(containerColor = SangvyaRed)
                                ) {
                                    Text("Find Nearby Peers", color = SangvyaWhite, fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = onNavigateToQr,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SangvyaGlassBorder)
                                ) {
                                    Text("Scan QR", color = SangvyaWhite, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            } else {
                items(connectedFriends, key = { it.id }) { friend ->
                    FriendCard(
                        friend = friend,
                        onChatClick = { onNavigateToPrivateChat(friend.id) },
                        onDisconnectClick = {
                            CoroutineScope(Dispatchers.IO).launch {
                                repository.disconnectFriend(friend.id)
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun QuickActionTile(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier,
        onClick = onClick,
        cornerRadius = 16.dp,
        backgroundColor = SangvyaGreyDark.copy(alpha = 0.45f)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = SangvyaRed,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                color = SangvyaWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun MetricColumn(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            color = SangvyaWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = SangvyaGreyDim,
            fontSize = 9.sp,
            letterSpacing = 0.8.sp
        )
    }
}

@Composable
fun FriendCard(
    friend: Friend,
    onChatClick: () -> Unit,
    onDisconnectClick: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onChatClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(SangvyaRedGlow),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = friend.displayName.take(1).uppercase(),
                    color = SangvyaWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = friend.displayName,
                        color = SangvyaWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusPill(status = friend.status)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = SangvyaRed,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = friend.formattedDistance,
                        color = SangvyaGreyLight,
                        fontSize = 12.sp
                    )
                    if (friend.bearingDegrees != null) {
                        Text(
                            text = " • ${friend.bearingDegrees.toInt()}°",
                            color = SangvyaGreyDim,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onChatClick) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "Chat",
                        tint = SangvyaWhite
                    )
                }
                IconButton(onClick = onDisconnectClick) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Disconnect",
                        tint = SangvyaGreyDim
                    )
                }
            }
        }
    }
}
