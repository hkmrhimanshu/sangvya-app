package com.sangvya.app

import android.app.Application
import com.sangvya.app.data.local.AppDatabase
import com.sangvya.app.data.location.LocationHelper
import com.sangvya.app.data.nearby.NearbyManager
import com.sangvya.app.data.preference.UserPreferencesRepository
import com.sangvya.app.data.repository.SangvyaRepository

class SangvyaApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var preferences: UserPreferencesRepository
        private set

    lateinit var nearbyManager: NearbyManager
        private set

    lateinit var locationHelper: LocationHelper
        private set

    lateinit var repository: SangvyaRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        preferences = UserPreferencesRepository(this)
        nearbyManager = NearbyManager(this)
        locationHelper = LocationHelper(this)

        repository = SangvyaRepository(
            context = this,
            database = database,
            preferences = preferences,
            nearbyManager = nearbyManager,
            locationHelper = locationHelper
        )
    }

    companion object {
        lateinit var instance: SangvyaApp
            private set
    }
}
