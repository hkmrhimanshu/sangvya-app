package com.sangvya.app

import android.app.Application
import android.util.Log
import com.sangvya.app.data.local.AppDatabase
import com.sangvya.app.data.location.LocationHelper
import com.sangvya.app.data.nearby.NearbyManager
import com.sangvya.app.data.nearby.OnlineMeshManager
import com.sangvya.app.data.nearby.P2pSocketManager
import com.sangvya.app.data.preference.UserPreferencesRepository
import com.sangvya.app.data.repository.SangvyaRepository
import java.util.UUID

class SangvyaApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var preferences: UserPreferencesRepository
        private set

    lateinit var nearbyManager: NearbyManager
        private set

    lateinit var onlineMeshManager: OnlineMeshManager
        private set

    lateinit var p2pSocketManager: P2pSocketManager
        private set

    lateinit var locationHelper: LocationHelper
        private set

    lateinit var repository: SangvyaRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Global Uncaught Exception Guard to prevent GMS/Nearby background crashes on low-end phones
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val message = throwable.message.orEmpty()
            val stack = Log.getStackTraceString(throwable)
            Log.e("SangvyaCrashGuard", "Caught exception on thread ${thread.name}: $message\n$stack")
            if (message.contains("Nearby") || message.contains("gms") || message.contains("Bluetooth") ||
                stack.contains("Nearby") || stack.contains("gms") || stack.contains("bluetooth") ||
                stack.contains("WifiDirect") || stack.contains("ConnectionsStatusCodes")
            ) {
                Log.w("SangvyaCrashGuard", "Silenced GMS/Nearby background crash")
            } else {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }

        database = AppDatabase.getInstance(this)
        preferences = UserPreferencesRepository(this)
        nearbyManager = NearbyManager(this)
        locationHelper = LocationHelper(this)

        val stableUserId = "sangvya_" + UUID.randomUUID().toString().take(8)
        onlineMeshManager = OnlineMeshManager(stableUserId)
        p2pSocketManager = P2pSocketManager(stableUserId)

        repository = SangvyaRepository(
            context = this,
            database = database,
            preferences = preferences,
            nearbyManager = nearbyManager,
            locationHelper = locationHelper,
            onlineMeshManager = onlineMeshManager,
            p2pSocketManager = p2pSocketManager
        )
    }

    companion object {
        lateinit var instance: SangvyaApp
            private set
    }
}
