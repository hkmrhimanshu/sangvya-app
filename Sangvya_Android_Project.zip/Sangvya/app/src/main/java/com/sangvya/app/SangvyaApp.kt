package com.sangvya.app

import android.app.Application
import android.util.Log
import com.sangvya.app.data.local.AppDatabase
import com.sangvya.app.data.location.LocationHelper
import com.sangvya.app.data.nearby.NearbyManager
import com.sangvya.app.data.nearby.OnlineMeshManager
import com.sangvya.app.data.nearby.P2pSocketManager
import com.sangvya.app.data.preference.UserPreferencesRepository
import com.sangvya.app.data.repository.SangvyaRepository
import java.util.UUID

class SangvyaApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var preferences: UserPreferencesRepository
        private set

    lateinit var nearbyManager: NearbyManager
        private set

    lateinit var onlineMeshManager: OnlineMeshManager
        private set

    lateinit var p2pSocketManager: P2pSocketManager
        private set

    lateinit var locationHelper: LocationHelper
        private set

    lateinit var repository: SangvyaRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Bulletproof Global Uncaught Exception Guard: Case-insensitive, prevents any crash
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val message = throwable.message.orEmpty().lowercase()
            val stack = Log.getStackTraceString(throwable).lowercase()
            Log.e("SangvyaCrashGuard", "Caught exception on thread ${thread.name}: $message\n$stack")

            val isNearbyOrGmsCrash = message.contains("nearby") || message.contains("gms") ||
                    message.contains("bluetooth") || message.contains("wifi") ||
                    stack.contains("nearby") || stack.contains("gms") ||
                    stack.contains("bluetooth") || stack.contains("wifidirect") ||
                    stack.contains("connectionsstatuscodes") || stack.contains("com.google.android.gms")

            if (isNearbyOrGmsCrash) {
                Log.w("SangvyaCrashGuard", "Silenced GMS/Nearby/Bluetooth background exception to prevent app crash")
            } else if (thread.name == "main") {
                if (stack.contains("nearby") || stack.contains("gms") || stack.contains("compose")) {
                    Log.w("SangvyaCrashGuard", "Silenced UI exception from GMS/Nearby/Compose")
                } else {
                    defaultHandler?.uncaughtException(thread, throwable)
                }
            } else {
                Log.w("SangvyaCrashGuard", "Silenced background worker thread exception: $message")
            }
        }

        database = AppDatabase.getInstance(this)
        preferences = UserPreferencesRepository(this)
        nearbyManager = NearbyManager(this)
        locationHelper = LocationHelper(this)

        val stableUserId = "sangvya_" + UUID.randomUUID().toString().take(8)
        onlineMeshManager = OnlineMeshManager(stableUserId)
        p2pSocketManager = P2pSocketManager(this, stableUserId)

        repository = SangvyaRepository(
            context = this,
            database = database,
            preferences = preferences,
            nearbyManager = nearbyManager,
            locationHelper = locationHelper,
            onlineMeshManager = onlineMeshManager,
            p2pSocketManager = p2pSocketManager
        )
    }

    companion object {
        lateinit var instance: SangvyaApp
            private set
    }
}
