package com.sangvya.app.data.model

import org.json.JSONObject

enum class QrType {
    INDIVIDUAL,
    GROUP
}

data class QrPayload(
    val protocol: String = "SANGVYA",
    val version: String = "2.0",
    val type: QrType,
    val userId: String,
    val displayName: String,
    val token: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): String {
        val json = JSONObject()
        json.put("protocol", protocol)
        json.put("version", version)
        json.put("type", type.name)
        json.put("userId", userId)
        json.put("displayName", displayName)
        json.put("token", token)
        json.put("timestamp", timestamp)
        return json.toString()
    }

    companion object {
        fun fromJson(raw: String): QrPayload? {
            return try {
                val json = JSONObject(raw)
                val proto = json.optString("protocol")
                if (proto != "SANGVYA") return null
                
                val typeStr = json.optString("type", QrType.INDIVIDUAL.name)
                val type = try {
                    QrType.valueOf(typeStr)
                } catch (e: Exception) {
                    QrType.INDIVIDUAL
                }

                QrPayload(
                    protocol = proto,
                    version = json.optString("version", "2.0"),
                    type = type,
                    userId = json.getString("userId"),
                    displayName = json.getString("displayName"),
                    token = json.optString("token", ""),
                    timestamp = json.optLong("timestamp", System.currentTimeMillis())
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
