package com.sangvya.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sangvya.app.data.model.Friend
import com.sangvya.app.ui.theme.SangvyaGlassBorder
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaRedGlow
import com.sangvya.app.ui.theme.SangvyaWhite
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun RadarCanvas(
    friends: List<Friend>,
    modifier: Modifier = Modifier,
    maxRangeMeters: Float = 500f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar_sweep")
    val angleDegrees by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep_angle"
    )

        val textMeasurer = rememberTextMeasurer()
    val friendLayouts = remember(friends) {
        friends.map { friend ->
            textMeasurer.measure(
                text = friend.displayName.take(8),
                style = TextStyle(
                    color = SangvyaWhite,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            )
        }
    }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = min(size.width, size.height) / 2f - 24.dp.toPx()
            if (radius <= 0f) return@Canvas

            val rings = 4
            for (i in 1..rings) {
                val currentR = radius * (i.toFloat() / rings)
                drawCircle(
                    color = SangvyaGlassBorder,
                    radius = currentR,
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            drawLine(
                color = SangvyaGlassBorder.copy(alpha = 0.3f),
                start = Offset(center.x, center.y - radius),
                end = Offset(center.x, center.y + radius),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = SangvyaGlassBorder.copy(alpha = 0.3f),
                start = Offset(center.x - radius, center.y),
                end = Offset(center.x + radius, center.y),
                strokeWidth = 1.dp.toPx()
            )

            val sweepRad = Math.toRadians(angleDegrees.toDouble())
            val sweepEnd = Offset(
                x = (center.x + radius * cos(sweepRad)).toFloat(),
                y = (center.y + radius * sin(sweepRad)).toFloat()
            )
            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(SangvyaRed.copy(alpha = 0.8f), Color.Transparent),
                    start = center,
                    end = sweepEnd
                ),
                start = center,
                end = sweepEnd,
                strokeWidth = 2.dp.toPx()
            )

            drawCircle(
                color = SangvyaRedGlow,
                radius = 16.dp.toPx(),
                center = center
            )
            drawCircle(
                color = SangvyaRed,
                radius = 6.dp.toPx(),
                center = center
            )

            friends.forEachIndexed { index, friend ->
                val dist = friend.distanceMeters ?: (100f + index * 50f)
                val normalizedDistance = (dist / maxRangeMeters).coerceIn(0.15f, 0.95f)
                val friendRadius = radius * normalizedDistance

                val bearing = friend.bearingDegrees ?: (index * (360f / maxOf(1, friends.size)))
                val rad = Math.toRadians((bearing - 90).toDouble())

                val fx = (center.x + friendRadius * cos(rad)).toFloat()
                val fy = (center.y + friendRadius * sin(rad)).toFloat()

                drawCircle(
                    color = SangvyaWhite.copy(alpha = 0.4f),
                    radius = 8.dp.toPx(),
                    center = Offset(fx, fy)
                )
                drawCircle(
                    color = SangvyaRed,
                    radius = 4.dp.toPx(),
                    center = Offset(fx, fy)
                )

                val name = friend.displayName.take(8)
                val textLayout = textMeasurer.measure(
                    text = name,
                    style = TextStyle(
                        color = SangvyaWhite,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                )
                drawText(
                    textLayoutResult = textLayout,
                    topLeft = Offset(fx - textLayout.size.width / 2f, fy + 8.dp.toPx())
                )
            }
        }
    }
}
