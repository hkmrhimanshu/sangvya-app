package com.sangvya.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.sangvya.app.data.repository.SangvyaRepository
import com.sangvya.app.ui.screens.GroupChatScreen
import com.sangvya.app.ui.screens.HomeScreen
import com.sangvya.app.ui.screens.LocationRadarScreen
import com.sangvya.app.ui.screens.NearbyScreen
import com.sangvya.app.ui.screens.PrivateChatScreen
import com.sangvya.app.ui.screens.QrHubScreen
import com.sangvya.app.ui.screens.SettingsScreen
import com.sangvya.app.ui.screens.SplashScreen

object Destinations {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val NEARBY = "nearby"
    const val QR = "qr"
    const val RADAR = "radar"
    const val PRIVATE_CHAT = "private_chat/{friendId}"
    const val GROUP_CHAT = "group_chat"
    const val SETTINGS = "settings"

    fun privateChatRoute(friendId: String) = "private_chat/$friendId"
}

@Composable
fun SangvyaNavHost(
    navController: NavHostController,
    repository: SangvyaRepository
) {
    NavHost(
        navController = navController,
        startDestination = Destinations.SPLASH
    ) {
        composable(Destinations.SPLASH) {
            SplashScreen(
                onSplashFinished = {
                    navController.navigate(Destinations.HOME) {
                        popUpTo(Destinations.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Destinations.HOME) {
            HomeScreen(
                repository = repository,
                onNavigateToNearby = { navController.navigate(Destinations.NEARBY) },
                onNavigateToQr = { navController.navigate(Destinations.QR) },
                onNavigateToRadar = { navController.navigate(Destinations.RADAR) },
                onNavigateToGroupChat = { navController.navigate(Destinations.GROUP_CHAT) },
                onNavigateToPrivateChat = { friendId ->
                    navController.navigate(Destinations.privateChatRoute(friendId))
                },
                onNavigateToSettings = { navController.navigate(Destinations.SETTINGS) }
            )
        }

        composable(Destinations.NEARBY) {
            NearbyScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Destinations.QR) {
            QrHubScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Destinations.RADAR) {
            LocationRadarScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Destinations.PRIVATE_CHAT,
            arguments = listOf(navArgument("friendId") { type = NavType.StringType })
        ) { backStackEntry ->
            val friendId = backStackEntry.arguments?.getString("friendId") ?: ""
            PrivateChatScreen(
                repository = repository,
                friendId = friendId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Destinations.GROUP_CHAT) {
            GroupChatScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Destinations.SETTINGS) {
            SettingsScreen(
                repository = repository,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
