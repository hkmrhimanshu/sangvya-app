package com.sangvya.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sangvya.app.R
import com.sangvya.app.data.model.DistanceAlertSettings
import com.sangvya.app.data.repository.SangvyaRepository
import com.sangvya.app.ui.components.GlassCard
import com.sangvya.app.ui.components.SangvyaTopBar
import com.sangvya.app.ui.theme.SangvyaBlack
import com.sangvya.app.ui.theme.SangvyaGlassBorder
import com.sangvya.app.ui.theme.SangvyaGreyDark
import com.sangvya.app.ui.theme.SangvyaGreyDim
import com.sangvya.app.ui.theme.SangvyaGreyLight
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaRedGlow
import com.sangvya.app.ui.theme.SangvyaSurfaceCard
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaRedGlow
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Icon
import com.sangvya.app.ui.theme.SangvyaWhite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    repository: SangvyaRepository,
    onNavigateBack: () -> Unit
) {
    val currentDisplayName by repository.preferences.displayNameFlow.collectAsState(initial = "Sangvya Peer")
    val locationSharing by repository.preferences.locationSharingFlow.collectAsState(initial = true)
    val alertSettings by repository.preferences.alertSettingsFlow.collectAsState(initial = DistanceAlertSettings())
    val blockedUsers by repository.preferences.blockedUsersFlow.collectAsState(initial = emptySet())

    var nameInput by remember(currentDisplayName) { mutableStateOf(currentDisplayName) }
    var isEditingName by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SangvyaBlack)
    ) {
        SangvyaTopBar(
            title = "SETTINGS & ABOUT",
            showBackButton = true,
            onBackClick = onNavigateBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "PROFILE IDENTITY",
                    color = SangvyaWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text(
                            text = "Display Name",
                            color = SangvyaGreyDim,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        if (isEditingName) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = SangvyaWhite,
                                        unfocusedTextColor = SangvyaWhite,
                                        focusedContainerColor = SangvyaGreyDark,
                                        unfocusedContainerColor = SangvyaGreyDark,
                                        focusedBorderColor = SangvyaRed,
                                        unfocusedBorderColor = SangvyaGlassBorder
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        CoroutineScope(Dispatchers.IO).launch {
                                            repository.preferences.setDisplayName(nameInput)
                                        }
                                        isEditingName = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SangvyaRed)
                                ) {
                                    Text("Save", color = SangvyaWhite)
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = currentDisplayName,
                                    color = SangvyaWhite,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Button(
                                    onClick = { isEditingName = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = SangvyaGreyDark),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Edit", color = SangvyaGreyLight, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "DISTANCE ALERTS",
                    color = SangvyaWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Nearby Proximity Alerts",
                                    color = SangvyaWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Notify when a connected peer enters threshold range",
                                    color = SangvyaGreyDim,
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = alertSettings.alertsEnabled,
                                onCheckedChange = { enable ->
                                    CoroutineScope(Dispatchers.IO).launch {
                                        repository.preferences.updateAlertSettings(
                                            alertSettings.copy(alertsEnabled = enable)
                                        )
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SangvyaWhite,
                                    checkedTrackColor = SangvyaRed,
                                    uncheckedThumbColor = SangvyaGreyDim,
                                    uncheckedTrackColor = SangvyaGreyDark
                                )
                            )
                        }

                        if (alertSettings.alertsEnabled) {
                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "Threshold: ${alertSettings.thresholdMeters.toInt()} meters",
                                color = SangvyaGreyLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Slider(
                                value = alertSettings.thresholdMeters,
                                onValueChange = { newDist ->
                                    CoroutineScope(Dispatchers.IO).launch {
                                        repository.preferences.updateAlertSettings(
                                            alertSettings.copy(thresholdMeters = newDist)
                                        )
                                    }
                                },
                                valueRange = 10f..1000f,
                                steps = 19,
                                colors = SliderDefaults.colors(
                                    thumbColor = SangvyaRed,
                                    activeTrackColor = SangvyaRed,
                                    inactiveTrackColor = SangvyaGreyDark
                                )
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Audible Sound", color = SangvyaWhite, fontSize = 13.sp)
                                Switch(
                                    checked = alertSettings.soundEnabled,
                                    onCheckedChange = { sound ->
                                        CoroutineScope(Dispatchers.IO).launch {
                                            repository.preferences.updateAlertSettings(
                                                alertSettings.copy(soundEnabled = sound)
                                            )
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = SangvyaWhite,
                                        checkedTrackColor = SangvyaRed,
                                        uncheckedThumbColor = SangvyaGreyDim,
                                        uncheckedTrackColor = SangvyaGreyDark
                                    )
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Haptic Vibration", color = SangvyaWhite, fontSize = 13.sp)
                                Switch(
                                    checked = alertSettings.vibrationEnabled,
                                    onCheckedChange = { vib ->
                                        CoroutineScope(Dispatchers.IO).launch {
                                            repository.preferences.updateAlertSettings(
                                                alertSettings.copy(vibrationEnabled = vib)
                                            )
                                        }
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = SangvyaWhite,
                                        checkedTrackColor = SangvyaRed,
                                        uncheckedThumbColor = SangvyaGreyDim,
                                        uncheckedTrackColor = SangvyaGreyDark
                                    )
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "PRIVACY & SECURITY",
                    color = SangvyaWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Share Live Coordinates",
                                    color = SangvyaWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Allow connected peers to calculate distance and spatial bearing",
                                    color = SangvyaGreyDim,
                                    fontSize = 11.sp
                                )
                            }
                            Switch(
                                checked = locationSharing,
                                onCheckedChange = { share ->
                                    CoroutineScope(Dispatchers.IO).launch {
                                        repository.preferences.setLocationSharing(share)
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SangvyaWhite,
                                    checkedTrackColor = SangvyaRed,
                                    uncheckedThumbColor = SangvyaGreyDim,
                                    uncheckedTrackColor = SangvyaGreyDark
                                )
                            )
                        }

                        if (blockedUsers.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Blocked Peers (${blockedUsers.size})",
                                color = SangvyaWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            blockedUsers.forEach { bId ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(bId, color = SangvyaGreyDim, fontSize = 12.sp)
                                    Button(
                                        onClick = {
                                            CoroutineScope(Dispatchers.IO).launch {
                                                repository.unblockFriend(bId)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SangvyaGreyDark),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("Unblock", color = SangvyaWhite, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "ABOUT SANGVYA",
                    color = SangvyaWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 24.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.sangvya_logo_about),
                            contentDescription = "Sangvya Official Brand Reference",
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "SANGVYA",
                            color = SangvyaWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.5.sp
                        )

                        Text(
                            text = "Version 3.0 (Build 3)",
                            color = SangvyaRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 1.0.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "com.sangvya.app",
                            color = SangvyaGreyDim,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Sangvya is an offline-first peer-to-peer mesh networking and real-time spatial friend locator. It operates autonomously without centralized cloud servers or hidden data tracking.",
                            color = SangvyaGreyLight,
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Made by Himanshu Bhardwaj",
                            color = SangvyaRed,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.0.sp
                        )
                    }
                }
            }

            // Contact with Himanshu Bhardwaj Section
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 20.dp,
                    backgroundColor = SangvyaSurfaceCard.copy(alpha = 0.9f),
                    borderColor = SangvyaRed.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(SangvyaRedGlow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Email,
                                    contentDescription = "Contact",
                                    tint = SangvyaRed,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column {
                                Text(
                                    text = "Contact with Himanshu Bhardwaj",
                                    color = SangvyaWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Feature Coming Soon",
                                    color = SangvyaGreyDim,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(SangvyaGreyDark)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "SOON",
                                color = SangvyaRed,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
