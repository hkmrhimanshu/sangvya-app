package com.sangvya.app.data.model

enum class MessageStatus {
    PENDING,
    SENT,
    DELIVERED,
    RECEIVED
}

data class ChatMessage(
    val id: String,
    val peerId: String,
    val senderName: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isIncoming: Boolean,
    val isGroup: Boolean = false,
    val status: MessageStatus = MessageStatus.SENT
)
