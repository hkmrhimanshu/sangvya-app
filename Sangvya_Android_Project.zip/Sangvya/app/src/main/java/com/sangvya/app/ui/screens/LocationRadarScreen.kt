package com.sangvya.app.ui.screens

import androidx.compose.foundation.layout.size

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sangvya.app.data.model.Friend
import com.sangvya.app.data.repository.SangvyaRepository
import com.sangvya.app.ui.components.GlassCard
import com.sangvya.app.ui.components.RadarCanvas
import com.sangvya.app.ui.components.SangvyaTopBar
import com.sangvya.app.ui.theme.SangvyaBlack
import com.sangvya.app.ui.theme.SangvyaGreenOnline
import com.sangvya.app.ui.theme.SangvyaGreyDark
import com.sangvya.app.ui.theme.SangvyaGreyDim
import com.sangvya.app.ui.theme.SangvyaGreyLight
import com.sangvya.app.ui.theme.SangvyaRed
import com.sangvya.app.ui.theme.SangvyaWhite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun LocationRadarScreen(
    repository: SangvyaRepository,
    onNavigateBack: () -> Unit
) {
    val connectedFriends by repository.connectedFriendsFlow.collectAsState(initial = emptyList())
    val userLocation by repository.userLocation.collectAsState()
    val isSharing by repository.preferences.locationSharingFlow.collectAsState(initial = true)
    val deviceHeading by repository.deviceHeading.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SangvyaBlack)
    ) {
        SangvyaTopBar(
            title = "SPATIAL RADAR",
            showBackButton = true,
            onBackClick = onNavigateBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 24.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RadarCanvas(
                            friends = connectedFriends,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(280.dp),
                            maxRangeMeters = 500f
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "SANGVYA SPATIAL RADAR (500m RANGE)",
                            color = SangvyaGreyDim,
                            fontSize = 10.sp,
                            letterSpacing = 1.0.sp
                        )
                    }
                }
            }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Live Location Sharing",
                                color = SangvyaWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (isSharing) "Broadcasting GPS coordinates to mesh" else "Location broadcasting paused",
                                color = if (isSharing) SangvyaGreenOnline else SangvyaGreyDim,
                                fontSize = 11.sp
                            )
                        }

                        Switch(
                            checked = isSharing,
                            onCheckedChange = { enable ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    repository.preferences.setLocationSharing(enable)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SangvyaWhite,
                                checkedTrackColor = SangvyaRed,
                                uncheckedThumbColor = SangvyaGreyDim,
                                uncheckedTrackColor = SangvyaGreyDark
                            )
                        )
                    }
                }
            }

            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = SangvyaGreyDark.copy(alpha = 0.3f)
                ) {
                    Column {
                        Text(
                            text = "GPS TELEMETRY",
                            color = SangvyaWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.0.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (userLocation != null) {
                            Text(
                                text = "Coordinates: %.5f, %.5f".format(userLocation!!.latitude, userLocation!!.longitude),
                                color = SangvyaGreyLight,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Accuracy: ±%.1f m • Satellite fix confirmed".format(userLocation!!.accuracy),
                                color = SangvyaGreyDim,
                                fontSize = 11.sp
                            )
                        } else {
                            Text(
                                text = "Acquiring GPS constellation lock...",
                                color = SangvyaGreyDim,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "PEER DISTANCES (${connectedFriends.size})",
                    color = SangvyaWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
            }

            if (connectedFriends.isEmpty()) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "No active peers on radar. Link nearby friends via QR or Nearby discovery to view spatial bearings.",
                            color = SangvyaGreyDim,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
            } else {
                items(connectedFriends, key = { it.id }) { friend ->
                    PeerDistanceCard(friend = friend, userHeading = deviceHeading)
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun PeerDistanceCard(friend: Friend, userHeading: Float = 0f) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = friend.displayName,
                    color = SangvyaWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = friend.getRelativeDirection(userHeading),
                    color = SangvyaRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (friend.bearingDegrees != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = "Bearing",
                        tint = SangvyaGreyLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = " ${friend.bearingDegrees.toInt()}° Azimuth",
                        color = SangvyaGreyLight,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
