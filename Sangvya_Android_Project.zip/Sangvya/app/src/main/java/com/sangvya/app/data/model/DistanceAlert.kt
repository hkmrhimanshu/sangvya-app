package com.sangvya.app.data.model

data class DistanceAlertSettings(
    val alertsEnabled: Boolean = true,
    val thresholdMeters: Float = 100f,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true
)
