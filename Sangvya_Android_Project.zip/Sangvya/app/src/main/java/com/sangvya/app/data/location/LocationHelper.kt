package com.sangvya.app.data.location

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.util.Log
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class UserLocation(
    val latitude: Double,
    val longitude: Double,
    val accuracy: Float = 5f,
    val timestamp: Long = System.currentTimeMillis()
)

class LocationHelper(private val context: Context) {

    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    private val locationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    private val sensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    private val _currentLocation = MutableStateFlow<UserLocation?>(null)
    val currentLocation: StateFlow<UserLocation?> = _currentLocation.asStateFlow()

    private val _deviceHeading = MutableStateFlow(0f)
    val deviceHeading: StateFlow<Float> = _deviceHeading.asStateFlow()

    private val _isTracking = MutableStateFlow(false)
    val isTracking: StateFlow<Boolean> = _isTracking.asStateFlow()

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            updateLocation(loc)
        }
    }

    private val nativeLocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            updateLocation(location)
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val sensorListener = object : SensorEventListener {
        private val rotationMatrix = FloatArray(9)
        private val orientationAngles = FloatArray(3)

        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientationAngles)
                val azimuth = Math.toDegrees(orientationAngles[0].toDouble())
                _deviceHeading.value = ((azimuth + 360) % 360).toFloat()
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    init {
        // Immediate cache seed so location is NEVER null on app launch!
        seedInitialLocation()
    }

    @SuppressLint("MissingPermission")
    private fun seedInitialLocation() {
        try {
            // Check native LocationManager caches (Network and GPS)
            val netLoc = locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            val gpsLoc = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            val passLoc = locationManager?.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)

            val bestLoc = listOfNotNull(gpsLoc, netLoc, passLoc).maxByOrNull { it.time }
            if (bestLoc != null) {
                updateLocation(bestLoc)
            }

            // Also check Fused cache
            fusedClient.lastLocation.addOnSuccessListener { loc: Location? ->
                if (loc != null) {
                    updateLocation(loc)
                }
            }
        } catch (e: Exception) {
            Log.w("LocationHelper", "Could not seed initial location: ${e.message}")
        }
    }

    private fun updateLocation(loc: Location) {
        _currentLocation.value = UserLocation(
            latitude = loc.latitude,
            longitude = loc.longitude,
            accuracy = if (loc.hasAccuracy()) loc.accuracy else 5f,
            timestamp = if (loc.time > 0) loc.time else System.currentTimeMillis()
        )
        if (loc.hasBearing() && loc.bearing > 0f) {
            _deviceHeading.value = loc.bearing
        }
    }

    @SuppressLint("MissingPermission")
    fun startLocationUpdates(intervalMs: Long = 2000L) {
        if (_isTracking.value) return
        seedInitialLocation()

        try {
            // 1. Fused Location Client (Priority High Accuracy, 0m distance threshold for stationary testing)
            val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMs)
                .setMinUpdateIntervalMillis(1000L)
                .setMinUpdateDistanceMeters(0f) // Crucial: must update even if stationary!
                .build()

            fusedClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
            _isTracking.value = true

            // 2. Native LocationManager as backup (Network Provider gets instant indoor fix!)
            try {
                if (locationManager?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true) {
                    locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,
                        intervalMs,
                        0f,
                        nativeLocationListener,
                        Looper.getMainLooper()
                    )
                }
                if (locationManager?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true) {
                    locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        intervalMs,
                        0f,
                        nativeLocationListener,
                        Looper.getMainLooper()
                    )
                }
            } catch (e: Exception) {
                Log.w("LocationHelper", "Native LocationManager request failed: ${e.message}")
            }

            // 3. Hardware Compass Sensor
            val rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            if (rotationSensor != null) {
                sensorManager?.registerListener(sensorListener, rotationSensor, SensorManager.SENSOR_DELAY_UI)
            }
        } catch (e: SecurityException) {
            Log.e("LocationHelper", "SecurityException requesting location updates", e)
            _isTracking.value = false
        } catch (e: Exception) {
            Log.e("LocationHelper", "Exception requesting location updates", e)
            _isTracking.value = false
        }
    }

    fun stopLocationUpdates() {
        if (!_isTracking.value) return
        try {
            fusedClient.removeLocationUpdates(locationCallback)
            locationManager?.removeUpdates(nativeLocationListener)
            sensorManager?.unregisterListener(sensorListener)
        } catch (e: Exception) {}
        _isTracking.value = false
    }

    companion object {
        fun calculateDistanceMeters(
            lat1: Double,
            lon1: Double,
            lat2: Double,
            lon2: Double
        ): Float {
            val earthRadius = 6371000.0
            val dLat = Math.toRadians(lat2 - lat1)
            val dLon = Math.toRadians(lon2 - lon1)
            val a = sin(dLat / 2) * sin(dLat / 2) +
                    cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                    sin(dLon / 2) * sin(dLon / 2)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return (earthRadius * c).toFloat()
        }

        fun calculateBearingDegrees(
            lat1: Double,
            lon1: Double,
            lat2: Double,
            lon2: Double
        ): Float {
            val phi1 = Math.toRadians(lat1)
            val phi2 = Math.toRadians(lat2)
            val deltaLambda = Math.toRadians(lon2 - lon1)

            val y = sin(deltaLambda) * cos(phi2)
            val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(deltaLambda)
            val theta = atan2(y, x)
            val bearing = (Math.toDegrees(theta) + 360.0) % 360.0
            return bearing.toFloat()
        }
    }
}
