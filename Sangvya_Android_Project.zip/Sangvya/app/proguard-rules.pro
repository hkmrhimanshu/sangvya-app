# Proguard rules for Sangvya
-keep class com.sangvya.app.data.local.entity.** { *; }
-keep class com.sangvya.app.data.model.** { *; }
-dontwarn com.google.android.gms.nearby.**
