@rem Gradle startup script for Windows
@echo off
setlocal

set APP_HOME=%~dp0

where gradle >nul 2>nul
if %ERRORLEVEL% equ 0 (
    gradle %*
    exit /b %ERRORLEVEL%
)

set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if exist "%WRAPPER_JAR%" (
    if defined JAVA_HOME (
        set "JAVACMD=%JAVA_HOME%\bin\java.exe"
    ) else (
        set "JAVACMD=java"
    )
    "%JAVACMD%" -jar "%WRAPPER_JAR%" %*
    exit /b %ERRORLEVEL%
)

echo Error: Gradle is not installed and gradle-wrapper.jar was not found.
exit /b 1
